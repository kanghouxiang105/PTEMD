use strict;
# two types of files: 
#1: fastaq files(left and right 111118_left_file1.fq and 222228_left_file2.fq) 
#2: fastaq ID to previous ID(111118_id_to_privious.txt 222228_id_to_privious.txt);
my %hash_length_TE1;
open (OUT_TEs,"$ARGV[0]");
$/="\>";
while (<OUT_TEs>) 
{
	#print $_;
	s/>$//;
	next if ($_ eq "");
	my $TE_IDS_111;
	my @pp_TE_fasta1=split(/\n/,$_);
	if ($pp_TE_fasta1[0]=~/([^\s]+)/) 
	{
		$TE_IDS_111=$1;
		#print $TE_IDS_111."\n";
	}
	my $seq11111;
	for (my $cdkhx1=1;$cdkhx1< @pp_TE_fasta1;$cdkhx1++) 
	{
		$seq11111.=$pp_TE_fasta1[$cdkhx1];
	}
	$hash_length_TE1{$TE_IDS_111}=length($seq11111);
}
close OUT_TEs;
$/="\n";
open (OUT1,">".$ARGV[3].".111118_left_file1.fq");  # left_data
open (OUT2,">".$ARGV[3].".222228_right_file2.fq");  # right_data
open (OUT3,">".$ARGV[3].".111118_id_to_privious_left.txt"); # left_data_support
open (OUT4,">".$ARGV[3].".222228_id_to_privious_right.txt"); # right_data_support
open (OUT55,">".$ARGV[3].".111118_two_files.txt"); # left_data_support
open (OUT66,">".$ARGV[3].".222228_two_files.txt"); # right_data_support



my $end_91="end_9"; my $start_91="start_91";

my @pp_infile1=glob ("$ARGV[1] $ARGV[2]");
my $file_sam_12=0; my $line_hahaha1=0;
my %hash22; my %hash2;
foreach my $fine_in1 (@pp_infile1) 
{
	$file_sam_12++;
    open (IN1,"$fine_in1");
    while (<IN1>) 
    {
	    chomp;
	    $line_hahaha1++;
	    if ($line_hahaha1%500000==0) 
	    {
	    	print "file $fine_in1 line $line_hahaha1\n";
			#last if ($line_hahaha1 eq "5000000");
			#last if ($line_hahaha1 eq "10000000");
	    }
	    next if ($_ eq "");
	    my @pp1=split(/\s+/,$_);
	    next if ($pp1[9]=~/NN/);
	    #if (($pp1[3]>=1) and ($pp1[3]<=15)) 
	    if (($pp1[3]>=1) and ($pp1[3]<=20)) 
	    {
=head
	        my $dddd4=0;
		    if ($pp1[5]=~/^(\d+)S\d+M$/) 
	        {
		         $dddd4=$1;
			     ##$hash22{$start_91}.=$_."\n";
			     if ($dddd4>=25) 
			     {
			         $hash22{$pp1[2]}{$start_91}.="_".$file_sam_12."\t".$_."\n";
			     }
	        }
=cut
            my $dddd4=0;
			if ($pp1[5]=~/^(\d+)S\d+M\d*I*D*\d*M*/) 
			{
				$dddd4=$1;
			    $hash22{$pp1[2]}{$start_91}.="_".$file_sam_12."\t".$_."\n";			 
			}
	    }
	    else
	    {
		    my $ddd1=0; my $ddd2=0; my $ddd4=0;
			#if ($pp1[5]=~/^(\d+)M(\d+)S$/)
		    if ($pp1[5]=~/(\d+)M\d+I*D*(\d+)M(\d+)S/) 
		    {
			    #$ddd1=0; $ddd2=$1; $ddd4=$2;
			    $ddd1=$1; $ddd2=$2; $ddd4=$3;
			    my $ddd3=$ddd1+$ddd2+$pp1[3];
			    if (($ddd3>=$hash_length_TE1{$pp1[2]}-20) and ($ddd3<=$hash_length_TE1{$pp1[2]}+1))
			    {
					#if ($ddd4>=25) 
			        #{
				    #    $hash2{$pp1[2]}{$end_91}.="_".$file_sam_12."\t".$_."\n";
			        #}
					$hash2{$pp1[2]}{$end_91}.="_".$file_sam_12."\t".$_."\n";
				}
			}
			elsif ($pp1[5]=~/(\d+)M(\d+)S$/)
			{
				$ddd1=0; $ddd2=$1; $ddd4=$2;
				my $ddd3=$ddd1+$ddd2+$pp1[3];
#				if (($ddd3>=$TE_LEN-15) and ($ddd3<=$TE_LEN+1))
				if (($ddd3>=$hash_length_TE1{$pp1[2]}-20) and ($ddd3<=$hash_length_TE1{$pp1[2]}+1))
				{
					#print $pp1[3]."\t".$ddd3."\t".$pp1[5]."\t$ddd4"."\n";
					##$hash2{$pp1[2]}{$end_91}.=$_."\n";
					$hash2{$pp1[2]}{$end_91}.="_".$file_sam_12."\t".$_."\n";
				}
			}
		}
	}
	close IN1;
}
#####################################
#####################################
open (OUT5, ">".$ARGV[3].".222228.txt");
open (OUT6, ">".$ARGV[3].".111118.txt");

my %hash_pxpxx811;
foreach my $TE_idxx1 (sort keys %hash2) 
{
my @pxpx1=split(/\n/,$hash2{$TE_idxx1}{$end_91});      # TE tail sequences
#================following is for end coverage(MS)===========#
#============================================================#
foreach my $linekk1 (@pxpx1) 
{
	print OUT5 $TE_idxx1."\t".$linekk1."\n";
	my @pxpx11=split(/\s+/,$linekk1);
	my $pst1=$pxpx11[4]; my $pst2=$pxpx11[6]; my $seq881=$pxpx11[10];
	my $seq88a1=$pxpx11[11];
	my $start1=0;  my $start2=0; 
	my $start3=0;  my $start4=0;
	#if ($pst2=~/^(\d+)M(\d+)S$/)
	#{
	#	$start1=$1; $start2=$2;
	#}
	if ($pst2=~/(\d+)M\d+I*D*(\d+)M(\d+)S/) 
	{
		$start1=$2; $start2=$3;
    }
	elsif ($pst2=~/(\d+)M(\d+)S$/)
	{
		$start1=$1; $start2=$2;
	}
	my $cdcd11=length($seq881); my $cdcd22=$cdcd11-$start2;
	my $seq882=substr($seq881,$cdcd22,$start2);
	my $seq88a2=substr($seq88a1,$cdcd22,$start2);
	my $change_yesno1="$pxpx11[1]"."$pxpx11[0]";
	###$hash_pxpxx811{$pxpx11[3]}{$seq882}{$seq881}{$cdcd22}{$start2}{$change_yesno1}{$pst2}=1;	
	$hash_pxpxx811{$pxpx11[3]}{$pxpx11[2]}{$seq88a2}{$seq88a1}{$seq882}{$seq881}{$cdcd22}{$start2}{$change_yesno1}{$pst2}=1;	
}
#####################################
#####################################
}
#####################################
#####################################

my $seq_number11=0;
foreach my $khxeys1 (sort keys %hash_pxpxx811) 
{
	foreach my $khxeys_add2 (keys %{$hash_pxpxx811{$khxeys1}}) 
	{
		foreach my $khxeys_add3 (keys %{$hash_pxpxx811{$khxeys1}{$khxeys_add2}}) 
		{
			foreach my $khxeys_add4 (keys %{$hash_pxpxx811{$khxeys1}{$khxeys_add2}{$khxeys_add3}}) 
			{
	            foreach my $khxeys2 (keys %{$hash_pxpxx811{$khxeys1}{$khxeys_add2}{$khxeys_add3}{$khxeys_add4}}) 
	            {
		            foreach my $khxeys3 (keys %{$hash_pxpxx811{$khxeys1}{$khxeys_add2}{$khxeys_add3}{$khxeys_add4}{$khxeys2}}) 
		            {
			            foreach my $khxeys4 (keys %{$hash_pxpxx811{$khxeys1}{$khxeys_add2}{$khxeys_add3}{$khxeys_add4}{$khxeys2}{$khxeys3}}) 
			            {
				            foreach my $khxeys5 (keys %{$hash_pxpxx811{$khxeys1}{$khxeys_add2}{$khxeys_add3}{$khxeys_add4}{$khxeys2}{$khxeys3}{$khxeys4}}) 
				            {
					            foreach my $khxeys6 (keys %{$hash_pxpxx811{$khxeys1}{$khxeys_add2}{$khxeys_add3}{$khxeys_add4}{$khxeys2}{$khxeys3}{$khxeys4}{$khxeys5}}) 
					            {
						            foreach my $khxeys7 (keys %{$hash_pxpxx811{$khxeys1}{$khxeys_add2}{$khxeys_add3}{$khxeys_add4}{$khxeys2}{$khxeys3}{$khxeys4}{$khxeys5}{$khxeys6}}) 
						            {
					                    if (length($khxeys2)>=10) 
					                    {
					                        $seq_number11++;
					                        #print OUT2 ">".$seq_number11."_".$khxeys1."\t".$khxeys3."\t".$khxeys4."\t".$khxeys5."\t".$khxeys6."\t".$khxeys7."\n";
					                        #print OUT2 $khxeys2."\n";
											my $f_r_result;
											if ($khxeys_add2 eq "0") {$f_r_result="+";}
											elsif ($khxeys_add2 eq "16") {$f_r_result="-";}
											#my $seq11_length=length()
											print OUT2 "@".$seq_number11."$f_r_result"."_".$khxeys6." ".$seq_number11." "."length=".$khxeys5."\n";
											print OUT2 $khxeys2."\n";
											print OUT2 "+".$seq_number11."$f_r_result"."_".$khxeys6." ".$seq_number11." "."length=".$khxeys5."\n";
											print OUT2 $khxeys_add3."\n"; 
											print OUT4 $seq_number11."\t".$f_r_result."\t".$khxeys1."\t".$khxeys6."\n";
											print OUT66 ">".$seq_number11."_".$khxeys1."\t".$khxeys6."\n";
											print OUT66 $khxeys2."\n";
											print OUT66 $seq_number11."_".$khxeys1."\t".$khxeys2."\t"."0"."\t".$khxeys5."\t".$khxeys6."\t"."0M".$khxeys5."S"."\n";
										}
					                }
					            }
				            }
			            }
		            }
	            }						
			}
		}
	}
}
close OUT2; close OUT4;
#######################################################################

my %hash_pxpxx822;
foreach my $TE_idxx2 (sort keys %hash22) 
{
my @xpxp1=split(/\n/,$hash22{$TE_idxx2}{$start_91});      # TE head sequences
#================following is for end coverage(MS)===========#
#============================================================#
foreach my $linekk1 (@xpxp1) 
{
	print OUT6 $TE_idxx2."\t".$linekk1."\n";
	my @pxpx11=split(/\s+/,$linekk1);
	my $pst1=$pxpx11[4]; my $pst2=$pxpx11[6]; 
	my $seq881=$pxpx11[10];
	my $seq88a1=$pxpx11[11];
	my $start1=0;  my $start2=0; 
	my $start3=0;  my $start4=0;
	###if ($pst2=~/^(\d+)S(\d+)M$/)
    if ($pst2=~/^(\d+)S(\d+)M\d*I*D*\d*M*/) 
	{
		$start1=$1; $start2=$2;
	}
	my $cdcd11=length($seq881); my $cdcd22=$cdcd11-$start2;
	my $seq882=substr($seq881,0,$start1);
	my $seq88a2=substr($seq88a1,0,$start1);
	my $change_yesno2="$pxpx11[1]"."$pxpx11[0]";
	###$hash_pxpxx811{$pxpx11[3]}{$seq882}{$seq881}{$cdcd22}{$start2}{$change_yesno1}{$pst2}=1;	
	$hash_pxpxx822{$pxpx11[3]}{$pxpx11[2]}{$seq88a2}{$seq88a1}{$seq882}{$seq881}{0}{$start1}{$change_yesno2}{$pst2}=1;
}
#####################################
#####################################
}
#####################################
#####################################

my $seq_number11=0;
foreach my $khxeys1 (sort keys %hash_pxpxx822) 
{
	foreach my $khxeys_add2 (keys %{$hash_pxpxx822{$khxeys1}}) 
	{
		foreach my $khxeys_add3 (keys %{$hash_pxpxx822{$khxeys1}{$khxeys_add2}}) 
		{
			foreach my $khxeys_add4 (keys %{$hash_pxpxx822{$khxeys1}{$khxeys_add2}{$khxeys_add3}}) 
			{
	            foreach my $khxeys2 (keys %{$hash_pxpxx822{$khxeys1}{$khxeys_add2}{$khxeys_add3}{$khxeys_add4}}) 
	            {
		            foreach my $khxeys3 (keys %{$hash_pxpxx822{$khxeys1}{$khxeys_add2}{$khxeys_add3}{$khxeys_add4}{$khxeys2}}) 
		            {
			            foreach my $khxeys4 (keys %{$hash_pxpxx822{$khxeys1}{$khxeys_add2}{$khxeys_add3}{$khxeys_add4}{$khxeys2}{$khxeys3}}) 
			            {
				            foreach my $khxeys5 (keys %{$hash_pxpxx822{$khxeys1}{$khxeys_add2}{$khxeys_add3}{$khxeys_add4}{$khxeys2}{$khxeys3}{$khxeys4}}) 
				            {
					            foreach my $khxeys6 (keys %{$hash_pxpxx822{$khxeys1}{$khxeys_add2}{$khxeys_add3}{$khxeys_add4}{$khxeys2}{$khxeys3}{$khxeys4}{$khxeys5}}) 
					            {
						            foreach my $khxeys7 (keys %{$hash_pxpxx822{$khxeys1}{$khxeys_add2}{$khxeys_add3}{$khxeys_add4}{$khxeys2}{$khxeys3}{$khxeys4}{$khxeys5}{$khxeys6}}) 
						            {
					                    if (length($khxeys2)>=10) 
					                    {
					                        $seq_number11++;
					                        #print OUT2 ">".$seq_number11."_".$khxeys1."\t".$khxeys3."\t".$khxeys4."\t".$khxeys5."\t".$khxeys6."\t".$khxeys7."\n";
					                        #print OUT2 $khxeys2."\n";
											my $f_r_result;
											if ($khxeys_add2 eq "0") {$f_r_result="+";}
											elsif ($khxeys_add2 eq "16") {$f_r_result="-";}
											#my $seq11_length=length()
											print OUT1 "@".$seq_number11."$f_r_result"."_".$khxeys6." ".$seq_number11." "."length=".$khxeys5."\n";
											print OUT1 $khxeys2."\n";
											print OUT1 "+".$seq_number11."$f_r_result"."_".$khxeys6." ".$seq_number11." "."length=".$khxeys5."\n";
											print OUT1 $khxeys_add3."\n"; 
											print OUT3 $seq_number11."\t".$f_r_result."\t".$khxeys1."\t".$khxeys6."\n";
											print OUT55 ">".$seq_number11."_".$khxeys1."\t".$khxeys6."\n";
											print OUT55 $khxeys2."\n";
											print OUT55 $seq_number11."_".$khxeys1."\t".$khxeys2."\t"."0"."\t".$khxeys5."\t".$khxeys6."\t".$khxeys5."S"."0M"."\n";
							            }
					                }
					            }
				            }
			            }
		            }
	            }						
			}
		}
	}
}
close OUT1; close OUT3;
close OUT5; close OUT6; 
close OUT55; close OUT66; 