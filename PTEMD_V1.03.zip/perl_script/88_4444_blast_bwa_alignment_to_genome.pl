use strict;
################################################################################
###### first part is BWA the brerk point sequence to the genome sequences#######
################################################################################
#my $file_in1="111118.txt.out";
#my $file_in2="222228.txt.out";
my $file_in1="$ARGV[6]".".111118_left_file1.fq";
#my $file_in2="222228_left_file2.fq";
my $file_in2="$ARGV[6]".".222228_right_file2.fq";

my $file_in11="$ARGV[6]".".111118_left_file1.fq".".sam";
my $file_in22="$ARGV[6]".".222228_right_file2.fq".".sam";

my $ffformatdb_path51="$ARGV[0]";
my $fffblastall_path51="$ARGV[1]";
my $balst_screen_path51="$ARGV[2]";
my $reference_genome51="$ARGV[3]";
my $active_TEs_file51="$ARGV[4]";
my $bwa_path_file51="$ARGV[5]";


my $active_TEs_file52="$ARGV[4]".".result1";
my $active_TEs_file53=$active_TEs_file52.".result1";
my $active_TEs_file54=$active_TEs_file53.".result1";


#system ("$bwa_path_file51  index $reference_genome51");
system ("$bwa_path_file51  mem $reference_genome51 -T 15  $file_in1 > $file_in11");
system ("$bwa_path_file51  mem $reference_genome51 -T 15  $file_in2 > $file_in22");

# nohup /media/data2/the_TE_project/test_bwa/TEMD_software/ATEMD-new2/bwa-0.7.10/bwa mem   /media/data2/the_TE_project/1000_human/genome/chroms/all_h38_genome.fa   222228_left_file2.fq > 222228_left_file2.fq.sam
# nohup /media/data2/the_TE_project/test_bwa/TEMD_software/ATEMD-new2/bwa-0.7.10/bwa mem   /media/data2/the_TE_project/1000_human/genome/chroms/all_h38_genome.fa   222228_left_file2.fq > 222228_left_file2.fq.sam  &
print  "Formating database\n";
system ("$ffformatdb_path51  -i $reference_genome51 -p F");
################################################################################
######## second part is blast the TEs sequences to the genome sequences#########
################################################################################
system ("$fffblastall_path51 -i $active_TEs_file51 -d $reference_genome51 -p blastn -F F -e 1e-20 -o $active_TEs_file52");
system ("perl $balst_screen_path51 -i $active_TEs_file52 -o $active_TEs_file53");

################################################################################
########## and them screen the TEs positions in the reference genome ###########
################################################################################
open (IN1,"$active_TEs_file53");
open (OUT1,">$active_TEs_file54");
my %hash1;
while (<IN1>) 
{
	chomp;
	next if ($_ eq "");
	my @pp1=split(/\t/,$_);
	if (($pp1[1]-$pp1[3]+$pp1[2]-1)<=20) 
	{
		my $match1; my $match2;
		if ($pp1[9]=~/(\d+)\/(\d+)/) 
		{
			$match1=$1; $match2=$2;
			if (($pp1[1]-$match2)>=-30 and ($pp1[1]-$match2)<=30) 
			{
				if ($pp1[10]>=96) 
				{
					if (($pp1[5]-$pp1[4])>0) 
					{
						print OUT1 "+"."\t".$_."\n";
					}
					elsif (($pp1[5]-$pp1[4])<0)
					{
						print OUT1 "-"."\t".$_."\n";
					}
				}
			}
		}

	}

}
close IN1; close OUT1;
