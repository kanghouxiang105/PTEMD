use strict;
my %hash_reverse_complement1;
$hash_reverse_complement1{A}="T"; $hash_reverse_complement1{T}="A"; $hash_reverse_complement1{G}="C"; $hash_reverse_complement1{C}="G"; $hash_reverse_complement1{N}="N";    
$hash_reverse_complement1{a}="T"; $hash_reverse_complement1{t}="A"; $hash_reverse_complement1{g}="C"; $hash_reverse_complement1{c}="G"; $hash_reverse_complement1{n}="N";

my $muscle_soft="$ARGV[0]";

open (IN1,"$ARGV[1]");
open (OUTX1,">$ARGV[2]");

$/="\>";
my %hash11;
while (<IN1>) 
{
	s/>$//;
	next if ($_ eq "");
	my @pp1=split(/\n/, $_);
	my $seq1;
	for (my $k1=1; $k1<@pp1 ; $k1++) 
	{
		$seq1.=$pp1[$k1];
	}
	my @pp2=split(/\s+/, $pp1[0]);
	my $length_seq1=length ($seq1);
	if ($pp2[0]=~/TE\_Cluster(\d+)\_(\d+)/) 
	{
		my $id11=$1;  my $id22=$2;
		$hash11{$id11}{$length_seq1}{$id22}=$seq1;
	}
}
close IN1;
$/="\n";

#my $muscle_path1="/media/data2/the_TE_project/test_bwa/TEMD_software/ATEMD-new2/muscle3.8.31_i86linux64";

##foreach my $keys1 (sort {$a<=>$b}  keys %hash11) 
foreach my $keys1 (sort {$a<=>$b}  keys %hash11) 
{
	my %hash22;    my %hash_min_set1;  my %hash_max_set1;
	my $add_line1=0;
	###foreach my $keys2 (sort {$b<=>$a} keys %{$hash11{$keys1}}) 
	foreach my $keys2 (keys %{$hash11{$keys1}}) 
	{
		foreach my $keys3 (keys %{$hash11{$keys1}{$keys2}}) 
		{
			$add_line1++;
			$hash22{$add_line1}=$hash11{$keys1}{$keys2}{$keys3};
		}
	}
	my $middle_111=$add_line1/3;
	my $middle_112=sprintf  "%.0f",  $middle_111;
	#####my $seq_max_len1=length($hash22{1});
	my $seq_max_len1=length($middle_112);
	for (my $k2=1; $k2<$add_line1+1; $k2++ ) 
	{
		my $seq_each1=$hash22{$k2};
		open (OUT1,">TEMD_SEQ_MUSCLE_SEQ2_tmp");
		#print OUT1 ">"."1"."\n".$hash22{1}."\n";
		print OUT1 ">"."1"."\n".$hash22{$middle_112}."\n";
		print OUT1 ">"."$k2"."\n".$hash22{$k2}."\n";
		close OUT1;
		system ("$muscle_soft -in TEMD_SEQ_MUSCLE_SEQ2_tmp -out TEMD_SEQ_MUSCLE_SEQ2_tmp_OUT2 -clw");
		open (IN22, "TEMD_SEQ_MUSCLE_SEQ2_tmp_OUT2");
		my $line_muscle_alignment1=0;
		my $totall_xin1=0;
		while (<IN22>) 
		{
			chomp;
			$line_muscle_alignment1++;
			#print $line_muscle_alignment1."\t".$_."\n";
			if ($line_muscle_alignment1>3) 
			{
				if (($line_muscle_alignment1-3)%4==3) 
				{
					my @ppp_muscle1=split(//,$_);
					for (my $kxxx1=0;$kxxx1<@ppp_muscle1; $kxxx1++) 
					{
						$totall_xin1++ if ($ppp_muscle1[$kxxx1]=~/\*/);
					}
				}
			}
		}
		close IN22;
		if ($seq_max_len1>0) 
		{
			if ($totall_xin1/$seq_max_len1 >=0.9) 
			{
				my $target_begin1; my $target_end1;
				####print OUTX1 "YES!!\n";
		        open (IN33, "TEMD_SEQ_MUSCLE_SEQ2_tmp_OUT2");
		        my $line_muscle_alignment3=0;
				my $length_of_seq_1=0;
				my $query_seq1="";  my $xin_xeq1="";
				my $len_query_plus_empty1=0;
				while (<IN33>) 
		        {
			        chomp;
			        $line_muscle_alignment3++;
					
					if ($line_muscle_alignment3>3) 
			        {
						if (($line_muscle_alignment3-3)%4==1) 
						{
							if ($_=~/([^\s]+\s+)([^\s]+)/) 
							{
								$len_query_plus_empty1=length ($1);
								#print "length  $len_query_plus_empty1\n";
								$query_seq1.=$2;
							}
						}
				        if (($line_muscle_alignment3-3)%4==3) 
				        {
							my @pp3=split(//,$_);
							for (my $k3=$len_query_plus_empty1; $k3<@pp3 ;$k3++) 
							{
								$xin_xeq1.=$pp3[$k3];
							}
						}
			        }
		        }
		        close IN33;
				####print OUTX1 $query_seq1."\n".$xin_xeq1."\n";
				my @pppp1=split(//,$xin_xeq1);
				for (my $kk_f1=0;$kk_f1<@pppp1 ;$kk_f1++) 
				{
					if ($pppp1[$kk_f1]=~/\*/) 
					{
						my $seq_tt1=substr($xin_xeq1, $kk_f1, 5);
						if ($seq_tt1=~/\*{5}/) 
						{
							$target_begin1=$kk_f1;
							my $small_seq_begin1=substr($query_seq1,0,$target_begin1);
							my $begin_cut1=0;
							my @pp_khxcd1=split(//,$small_seq_begin1);
							for (my $cdcd1=0;$cdcd1<@pp_khxcd1 ;$cdcd1++) 
							{
								$begin_cut1++ if ($pp_khxcd1[$cdcd1]=~/\w/gi);
							}
							$hash_min_set1{$begin_cut1}{$k2}=1;
							##$hash_min_set1{$target_begin1}{$k2}=1;
							####print OUTX1 $begin_cut1."\n";
							last;
						}
					}
				}
				for (my $kk_r1=@pppp1-1; $kk_r1>-1 ;$kk_r1-- ) 
				{
					if ($pppp1[$kk_r1]=~/\*/) 
					{
						my $seq_tt2=substr ($xin_xeq1, $kk_r1-5, 5);
						if ($seq_tt2=~/\*{5}/) 
						{
							$target_end1=$kk_r1;
							my $small_seq_end1=substr($query_seq1,$kk_r1,@pppp1-$kk_r1+1);
							my $end_cut1=0;
							my @pp_khxcd2=split(//, $small_seq_end1);
							for (my $cdcd2=0;$cdcd2<@pp_khxcd2 ;$cdcd2++) 
							{
								$end_cut1++ if ($pp_khxcd2[$cdcd2]=~/\w/gi);
							}
							$hash_max_set1{$end_cut1}{$k2}=1;
							##$hash_max_set1{$target_end1}{$k2}=1;
							####print OUTX1 $end_cut1."\n";
							last;
						}
					}
				}
			}
			elsif ($totall_xin1/$seq_max_len1 < 0.9)
			{
				##########
				my $target_begin2; my $target_end2;
				####print OUTX1 "NO!! reverse\n";
				my $reverse_seq_881=reverse ($hash22{$k2});
				my @pp_reverse1=split(//,$reverse_seq_881);
				my $reverse_seq_882;
				for (my $khx_k1=0;$khx_k1<@pp_reverse1 ;$khx_k1++) 
				{
					if ($pp_reverse1[$khx_k1]=~/\w/gi) 
					{
						if (exists $hash_reverse_complement1{$pp_reverse1[$khx_k1]}) 
						{
							$reverse_seq_882.=$hash_reverse_complement1{$pp_reverse1[$khx_k1]};
						}
						else{$reverse_seq_882.="N";}
					}
				}
				##########
		        open (OUT2,">TEMD_SEQ_MUSCLE_SEQ2_tmp");
		        #print OUT2 ">"."1"."\n".$hash22{1}."\n";
		        print OUT2 ">"."1"."\n".$hash22{$middle_112}."\n";
		        print OUT2 ">"."$k2"."\n".$reverse_seq_882."\n";
		        close OUT2;
		        system ("$muscle_soft -in TEMD_SEQ_MUSCLE_SEQ2_tmp -out TEMD_SEQ_MUSCLE_SEQ2_tmp_OUT2 -clw");
		        open (IN44, "TEMD_SEQ_MUSCLE_SEQ2_tmp_OUT2");
		        my $line_muscle_alignment4=0;
				my $length_of_seq_1=0;
				my $query_seq1="";  my $xin_xeq1="";
				my $len_query_plus_empty1=0;
				while (<IN44>) 
		        {
			        chomp;
			        $line_muscle_alignment4++;
					
					if ($line_muscle_alignment4>3) 
			        {
						if (($line_muscle_alignment4-3)%4==1) 
						{
							if ($_=~/([^\s]+\s+)([^\s]+)/) 
							{
								$len_query_plus_empty1=length ($1);
								$query_seq1.=$2;
							}
						}
				        if (($line_muscle_alignment4-3)%4==3) 
				        {
							my @pp3=split(//,$_);
							for (my $k3=$len_query_plus_empty1; $k3<@pp3 ;$k3++) 
							{
								$xin_xeq1.=$pp3[$k3];
							}
						}
			        }
		        }
		        close IN44;
				####print OUTX1 $query_seq1."\n".$xin_xeq1."\n";
				my @pppp1=split(//,$xin_xeq1);
				for (my $kk_f1=0;$kk_f1<@pppp1 ;$kk_f1++) 
				{
					if ($pppp1[$kk_f1]=~/\*/) 
					{
						my $seq_tt1=substr($xin_xeq1, $kk_f1, 5);
						if ($seq_tt1=~/\*{5}/) 
						{
							$target_begin2=$kk_f1;
							my $small_seq_begin1=substr($query_seq1,0,$target_begin2);
							my $begin_cut1=0;
							my @pp_khxcd1=split(//,$small_seq_begin1);
							for (my $cdcd1=0;$cdcd1<@pp_khxcd1 ;$cdcd1++) 
							{
								$begin_cut1++ if ($pp_khxcd1[$cdcd1]=~/\w/gi);
							}
							####print OUTX1 $begin_cut1."\n";
							$hash_min_set1{$begin_cut1}{$k2}=1;
							##$hash_min_set1{$target_begin2}{$k2}=1;
							last;
						}
					}
				}
				for (my $kk_r1=@pppp1-1; $kk_r1>-1 ;$kk_r1-- ) 
				{
					if ($pppp1[$kk_r1]=~/\*/) 
					{
						my $seq_tt2=substr ($xin_xeq1, $kk_r1-5, 5);
						if ($seq_tt2=~/\*{5}/) 
						{
							$target_end2=$kk_r1;
							my $small_seq_end1=substr($query_seq1,$kk_r1,@pppp1-$kk_r1+1);
							my $end_cut1=0;
							my @pp_khxcd2=split(//, $small_seq_end1);
							for (my $cdcd2=0;$cdcd2<@pp_khxcd2 ;$cdcd2++) 
							{
								$end_cut1++ if ($pp_khxcd2[$cdcd2]=~/\w/gi);
							}
							####print OUTX1 $end_cut1."\n";
							$hash_max_set1{$end_cut1}{$k2}=1;						
							##$hash_max_set1{$target_end2}{$k2}=1;
							last;
						}
					}
				}
			}
		}
	}
    #my %hash_min_set1;  my %hash_max_set1; $add_line1;
	my $last_begin_position1=0; my $last_end_position1=0;
	my $line_xxxx1=0; my $line_xxxx2=0; 
	foreach my $kkkeys1 (sort {$a<=>$b} keys %hash_min_set1) 
	{
		foreach my $kkkeys11 (keys %{$hash_min_set1{$kkkeys1}}) 
		{
		    $line_xxxx1++;
		    if ($add_line1>0) 
		    {
		        if ($line_xxxx1/$add_line1>=0.4) 
			    {
				    $last_begin_position1=$kkkeys1;
				    last;
		        }
		    }
		}
	}
	foreach my $kkkeys2 (sort {$a<=>$b} keys %hash_max_set1) 
	{
		foreach my $kkkeys22 (keys %{$hash_max_set1{$kkkeys2}}) 
		{
		    $line_xxxx2++;
		    if ($add_line1>0) 
		    {
			    if ($line_xxxx2/$add_line1>=0.4) 
			    {
				    $last_end_position1=$kkkeys2;
				    last;
			    }
		    }
		}
	}
	#print OUTX1 "$keys1 begain_and_end: $last_begin_position1 $last_end_position1\n";
	my $sssss1= $last_begin_position1;
	###my $eeeee1=length ($hash22{1}) - $last_begin_position1-$last_end_position1+1;
	my $eeeee1=length ($hash22{$middle_112}) - $last_begin_position1-$last_end_position1+1;
	#print OUTX1 "data $sssss1 $eeeee1\n";
	##my $tttget_seq1=substr ($hash22{1},$sssss1 ,$eeeee1 );	
	my $tttget_seq1=substr ($hash22{$middle_112},$sssss1 ,$eeeee1 );	
	print OUTX1 ">".$keys1."\tTE_cluster_".$keys1."\n";
	print OUTX1 $tttget_seq1."\n";
}
close OUTX1; 