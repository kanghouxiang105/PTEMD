use strict;
my %hash_length_TE1;
open (OUT_TEs, "$ARGV[0]")||die;
$/="\>";
while (<OUT_TEs>) 
{
	s/>$//;
	next if ($_ eq "");
	my $TE_IDS_111;
	my @pp_TE_fasta1=split(/\n/,$_);
	if ($pp_TE_fasta1[0]=~/([^\s]+)/) 
	{
		$TE_IDS_111=$1;
		#print $TE_IDS_111."\n";
	}
	my $seq11111;
	for (my $cdkhx1=1; $cdkhx1< @pp_TE_fasta1; $cdkhx1++) 
	{
		$seq11111.=$pp_TE_fasta1[$cdkhx1];
	}
	$hash_length_TE1{$TE_IDS_111}=length($seq11111);
	#print $_."\n";
}
close OUT_TEs;
$/="\n";

my %hash_all_te881;  my %hash_all_te882;
my $file_in1="$ARGV[1]".".111118_left_file1.fq.sam";
my $file_in2="$ARGV[1]".".222228_right_file2.fq.sam";
open (IN1,"$file_in1");
open (IN2,"$file_in2");

my %hash_number_to_id_left_1; my %hash_number_to_id_right_1; # number to ID;
### here need to use the two files:
open (IN1_left_N_TO_ID,  "$ARGV[1]".".111118_id_to_privious_left.txt");
open (IN2_right_N_TO_ID, "$ARGV[1]".".222228_id_to_privious_right.txt");
while (<IN1_left_N_TO_ID>) 
{
	chomp;
	next if ($_ eq "");
	my @ppcdcd1=split(/\s+/,$_);
	$hash_number_to_id_left_1{$ppcdcd1[0]}=$ppcdcd1[2];
	#print "$ppcdcd1[0]  $ppcdcd1[2]\n";
}
close IN1_left_N_TO_ID; 
while (<IN2_right_N_TO_ID>) 
{
	chomp;
	next if ($_ eq "");
	my @ppcdcd2=split(/\s+/,$_);
	$hash_number_to_id_right_1{$ppcdcd2[0]}=$ppcdcd2[2];
	#print "$ppcdcd2[0]  $ppcdcd2[2]\n";
}
close IN2_right_N_TO_ID;

while (<IN1>) 
{
	chomp;
	next if ($_ eq "");
	my @ppppp1=split(/\s+/,$_);
	if ($ppppp1[0]=~/^(\d+)/) 
	{

		my $ha1=$1;
		my $id_real_hehe1=$hash_number_to_id_left_1{$ha1};
		$hash_all_te881{$id_real_hehe1}.=$_."\n";
		#print "$id_real_hehe1 $ha1\n";
	}
}
close IN1;
while (<IN2>) 
{
	chomp;
	next if ($_ eq "");
	my @ppppp2=split(/\s+/,$_);
	if ($ppppp2[0]=~/^(\d+)/) 
	{
		my $ha2=$1;
		my $id_real_hehe1=$hash_number_to_id_right_1{$ha2};
		$hash_all_te882{$id_real_hehe1}.=$_."\n";
		#print "2 $id_real_hehe1 $ha2\n";
	}
}
close IN2;

open (OUT1,">"."$ARGV[1]".".Result_forward11_22_break.txt");
open (OUT2,">"."$ARGV[1]".".Result_forward11_22_reference.txt");
open (OUT3,">"."$ARGV[1]".".Result_reward11_22_break.txt");
open (OUT4,">"."$ARGV[1]".".Result_reward11_22_reference.txt");

#open (OUT5,">88single_forward_left_break.txt");
#open (OUT6,">88single_forward_right_break.txt");
#open (OUT7,">88single_reward_left_break.txt");
#open (OUT8,">88single_reward_right_break.txt");


foreach my $kkkeys1 (sort keys %hash_all_te881) 
{
	print "processing TE sequence: $kkkeys1\n";	
	##print "processing TE sequence: 1\n";	
	my $each_TE_length=$hash_length_TE1{$kkkeys1};
	###my $each_TE_length=$hash_length_TE1{1};
	open (FILE1,">"."$ARGV[1]".".TEs1_temp.tem");
	open (FILE2,">"."$ARGV[1]".".TEs2_temp.tem");
	##print FILE1 $hash_all_te881{$kkkeys1}."\n";
	##print FILE2 $hash_all_te882{$kkkeys1}."\n";
	print FILE1 $hash_all_te881{$kkkeys1}."\n";
	print FILE2 $hash_all_te882{$kkkeys1}."\n";
    close FILE1; close FILE2;
    ##############################
	## setup %hash dataset: %hash_forward_left1; %hash_reward_left1; %hash_forward_right1;  %hash_reward_right1;
	##############################
	my %hash_forward_left1; my %hash_reward_left1; my %hash_forward_right1;  my %hash_reward_right1;
	open (IN_left_file1, "$ARGV[1]".".TEs1_temp.tem");
	open (IN_right_file1,"$ARGV[1]".".TEs2_temp.tem");
	while (<IN_left_file1>) 
	{
		chomp;
		next if ($_ eq "");
		my @pp1=split(/\s+/, $_);
		my $number_1111; my $ffff_rrrr1;
		if ($pp1[0]=~/^(\d+)([^\_])\_/) 
		{
			$number_1111=$1; $ffff_rrrr1=$2;
			my $match_111=0;
			if ($pp1[5]=~/^(\d+)M$/) 
			{
				$match_111=$1;
			    my $chr_position111=$pp1[3]+$match_111-1;
			    my $chr_position222=$pp1[3];
			    if ($pp1[1] eq "0") 
			    {
			        #$hash_forward_left1{$pp1[11]}{$pp1[5]}.=$pp1[0]."\t".$pp1[2]."\t".$pp1[3]."\n";
				    $hash_forward_left1{$pp1[2]}{$chr_position111}.=$number_1111."_".$hash_number_to_id_left_1{$number_1111}."\t"."1"."\t".$match_111."\n";
			    }
			    elsif ($pp1[1] eq "16")
			    {
				    $hash_reward_left1{$pp1[2]}{$chr_position222}.=$number_1111."_".$hash_number_to_id_left_1{$number_1111}."\t"."1"."\t".$match_111."\n";
			    }
			}
		}
	}
	close IN_left_file1;
	while (<IN_right_file1>) 
	{
		chomp;
		next if ($_ eq "");
		my @pp1=split(/\t/, $_);
		my $number_1111; my $ffff_rrrr1;
		if ($pp1[0]=~/^(\d+)([^\_])\_/) 
		{
			$number_1111=$1; $ffff_rrrr1=$2;
			my $match_111=0;
			if ($pp1[5]=~/^(\d+)M$/) 
			{   
				$match_111=$1;
			    my $chr_position111=$pp1[3];
			    my $chr_position222=$pp1[3]+$match_111-1;
			    if ($pp1[1] eq "0") 
			    {
			       #$hash_forward_left1{$pp1[11]}{$pp1[5]}.=$pp1[0]."\t".$pp1[2]."\t".$pp1[3]."\n";
				   $hash_forward_right1{$pp1[2]}{$chr_position111}.=$number_1111."_".$hash_number_to_id_right_1{$number_1111}."\t"."1"."\t".$match_111."\n";
			    }
			    elsif ($pp1[1] eq "16")
			    {
				   $hash_reward_right1{$pp1[2]}{$chr_position222}.=$number_1111."_".$hash_number_to_id_right_1{$number_1111}."\t"."1"."\t".$match_111."\n";
			    }
			}
		}	
	}
	close IN_right_file1;
    #########################################################
	foreach my $keys1 (sort keys %hash_forward_left1) 
	{
		foreach my $keys2 (sort {$a<=>$b} keys %{$hash_forward_left1{$keys1}}) 
		{
            #########################################################
			my $left_position1=$each_TE_length+$keys2;
			#for (my $kk1=$left_position1-2;$kk1<$left_position1+3 ;$kk1++) 
			for (my $kk1=$left_position1-2;$kk1<$left_position1+3 ;$kk1++) 
			{
				if (exists $hash_forward_right1{$keys1}{$kk1}) 
				{
					my $left_data111=$hash_forward_left1{$keys1}{$keys2};
					my $right_data111=$hash_forward_right1{$keys1}{$kk1};
					my @ppxx1=split(/\n/,$left_data111); my @ppxx2=split(/\n/,$right_data111);
					foreach my $hehe1 (@ppxx1) 
					{
						my @ppxx11=split(/\t/,$hehe1);
						foreach my $hehe2 (@ppxx2) 
						{
							my @ppxx22=split(/\t/,$hehe2);
							print OUT2 $keys1."\t".$ppxx11[0]."\t".$keys1."\t".$ppxx22[0]."\t";
							print OUT2 $keys2."\t".$kk1."\t".$ppxx11[1]."\t".$ppxx11[2]."\t";
							print OUT2 $ppxx22[1]."\t".$ppxx22[2]."\n";
						}
					}
				}
			}
            #########################################################
			my $left_position2=$keys2;
			#for (my $kk2=$left_position2-2;$kk2<$left_position2+3;$kk2++ ) 
			for (my $kk2=$left_position2-35;$kk2<$left_position2+3;$kk2++ ) 
			{
				if (exists $hash_forward_right1{$keys1}{$kk2}) 
				{
					my $left_data222=$hash_forward_left1{$keys1}{$keys2};
					my $right_data222=$hash_forward_right1{$keys1}{$kk2};
					my @ppxx3=split(/\n/,$left_data222); my @ppxx4=split(/\n/,$right_data222);
					foreach my $hehe3 (@ppxx3) 
					{
						my @ppxx33=split(/\t/,$hehe3);
						foreach my $hehe4 (@ppxx4) 
						{
							my @ppxx44=split(/\t/, $hehe4);
							print OUT1 $keys1."\t".$ppxx33[0]."\t".$keys1."\t".$ppxx44[0]."\t";
							print OUT1 $keys2."\t".$kk2."\t".$ppxx33[1]."\t".$ppxx33[2]."\t";
							print OUT1 $ppxx44[1]."\t".$ppxx44[2]."\n";
						}
					}
				}
			}
            #########################################################
		}
	}
    #########################################################
	#hash_reward_left1
	foreach my $keys1 (sort keys %hash_reward_left1) 
	{
		foreach my $keys2 (sort {$a<=>$b} keys %{$hash_reward_left1{$keys1}}) 
		{
            #########################################################
			my $other_position1=$keys2-$each_TE_length;
			for (my $kkk1=$other_position1-2;$kkk1<$other_position1+3;$kkk1++) 
			#for (my $kkk1=$other_position1-2;$kkk1<$other_position1+2;$kkk1++) 
			{
				if (exists $hash_reward_right1{$keys1}{$kkk1}) 
				{
					my $left_data1111=$hash_reward_left1{$keys1}{$keys2};
					my $right_data1111=$hash_reward_right1{$keys1}{$kkk1};
					my @ppxx5=split(/\n/,$left_data1111); my @ppxx6=split(/\n/,$right_data1111);
					foreach my $hehe1 (@ppxx5) 
					{
						my @ppxx55=split(/\t/,$hehe1);
						foreach my $hehe2 (@ppxx6) 
						{
							my @ppxx66=split(/\t/,$hehe2);
							print OUT4 $keys1."\t".$ppxx55[0]."\t".$keys1."\t".$ppxx66[0]."\t";
							print OUT4 $keys2."\t".$kkk1."\t".$ppxx55[1]."\t".$ppxx55[2]."\t";
							print OUT4 $ppxx66[1]."\t".$ppxx66[2]."\n";
						}
					}
				}
			}
            #########################################################
            #########################################################
			my $other_position2=$keys2;
			#for (my $kkk1=$other_position2-2;$kkk1<$other_position2+3;$kkk1++) 
			for (my $kkk1=$other_position2-2;$kkk1<$other_position2+36;$kkk1++) 
			{
				if (exists $hash_reward_right1{$keys1}{$kkk1}) 
				{
					my $left_data1111=$hash_reward_left1{$keys1}{$keys2};
					my $right_data1111=$hash_reward_right1{$keys1}{$kkk1};
					my @ppxx7=split(/\n/,$left_data1111); my @ppxx8=split(/\n/,$right_data1111);
					foreach my $hehe1 (@ppxx7) 
					{
						my @ppxx77=split(/\t/,$hehe1);
						foreach my $hehe2 (@ppxx8) 
						{
							my @ppxx88=split(/\t/,$hehe2);
							print OUT3 $keys1."\t".$ppxx77[0]."\t".$keys1."\t".$ppxx88[0]."\t";
							print OUT3 $keys2."\t".$kkk1."\t".$ppxx77[1]."\t".$ppxx77[2]."\t";
							print OUT3 $ppxx88[1]."\t".$ppxx88[2]."\n";
						}
					}
				}
			}
            #########################################################

		}
	}
    #########################################################


}
close OUT1; close OUT2; close OUT3; close OUT4;



