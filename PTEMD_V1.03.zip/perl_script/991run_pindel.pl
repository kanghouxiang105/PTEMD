use strict;
######################################################
############detect the deletion using Pindel##########
######################################################

#my $path1="/media/data1/kanghouxiang/pan_genome_paper/pindel/sam2pindel";     $ARGV[0]
#my $path2="/media/data1/kanghouxiang/pan_genome_paper/pindel/pindel_x86_64";  $ARGV[1]
#my $input_file="/media/data1/kanghouxiang/test_pindel/YN125.sam";             $ARGV[2]
# system ("perl 991run_pindel.pl $Pindel_sam2pindel_path $Pindel_path $opt_s $opt_i $Expect1 $software_pathdir_11");

my $path1="$ARGV[0]";
my $path2="$ARGV[1]";
my $input_file="$ARGV[2]";
my $software_all_path11="$ARGV[5]";
my $file_name11;
if ($input_file=~/\/*([^\/]+).sam$/) 
{
	$file_name11=$1;
}
my $file_name22=$file_name11."_TEMD-A";
my $file_name33=$file_name11."_TEMD-A1";
#steps:
##############################
#samtools view -h -o YN673_1bei_bwa.sort.sam   YN673_1bei_bwa.sort.bam
#/media/data1/kanghouxiang/pan_genome_paper/pindel/sam2pindel ./YN125.sam Output4Pindel_1.txt 500 blast 0
#/media/data1/kanghouxiang/pan_genome_paper/pindel/pindel_x86_64 ./toplevel.fasta  Output4Pindel_1.txt  ./kk_chr8.1  empty 5 3  Chromosome_8.1
open (IN1,"$ARGV[3]")||die "can't open the $ARGV[3] file"; my @pp_chrs;
while (<IN1>) 
{
	chomp;
	next if ($_ eq "");
	if ($_=~/\>([^\s]+)\s*/) 
	{
		push (@pp_chrs, $1);
		print $1."\n";
	}
}
close IN1;
##############################
system ("mkdir $file_name33");  system ("chmod 777 $file_name33"); 
system ("$path1 $input_file $file_name22 $ARGV[4] blast 0");
foreach my $chr1 (@pp_chrs) 
{	 
     system ("$path2 $ARGV[3] ./$file_name22 ./$file_name33 empty 5 3 $chr1");
}
######################################################


