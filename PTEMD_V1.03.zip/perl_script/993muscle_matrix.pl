use strict;

my %hash_reverse_complement1;
$hash_reverse_complement1{A}="T"; $hash_reverse_complement1{T}="A"; $hash_reverse_complement1{G}="C"; $hash_reverse_complement1{C}="G"; $hash_reverse_complement1{N}="N";    
$hash_reverse_complement1{a}="T"; $hash_reverse_complement1{t}="A"; $hash_reverse_complement1{g}="C"; $hash_reverse_complement1{c}="G"; $hash_reverse_complement1{n}="N";

my $input_file_11_33="$ARGV[0]"; #input file name
my $input_file_11_33_11="$ARGV[0]".".out";
open (IN1,"$input_file_11_33");  
open (OUT1,">$ARGV[1]");
open (INSEQ1,">$input_file_11_33_11");
my $iiiiddd1=$ARGV[2]/100;
my %hash1;  my %hash2; my %hash_martrix1; my %hash_max_min_1;
my $id=0; my $threshould1="$iiiiddd1"; 
my @pp_id1;
$/="\>"; 
while (<IN1>) 
{
	s/>$//;
	next if ($_ eq "");
	my @pp1=split(/\n/,$_);
	my $isoalte1; my $annotation1; my $seq1;
	if ($pp1[0]=~/([^\s]+)(.+)/) 
	{
		$isoalte1=$1; $annotation1=$2;
	}
	for (my $k1=1;$k1<@pp1 ;$k1++) 
	{
	    $seq1.=$pp1[$k1];
	}
	if (($isoalte1 ne "") and ($seq1 ne "")) 
	{
		$id++;
		print INSEQ1 ">$id\t$annotation1\n";
		print INSEQ1 $seq1."\n";
		$hash1{$id}=$seq1;
		$hash2{$id}=$annotation1;
	}
}
close IN1;  close INSEQ1;
##############################################################
##############MAKE A MATRIX USING Muscle SOFTWARE###############
$/="\n";


open (XXXXX1, ">XXXXX.txt");
for (my $khx1=1;$khx1<$id; $khx1++) 
{
	print XXXXX1 $khx1."\t";
	for (my $khx2=$khx1+1; $khx2<$id+1 ;$khx2++) 
	{
		my $Q_size1=length($hash1{$khx1});
		my $T_size1=length($hash1{$khx2});
		if (($Q_size1>0) and ($T_size1>0)) 
		{
			my @pp_max11=();   my @pp_min11=();
			if (($Q_size1/$T_size1>=0.9) and  ($T_size1/$Q_size1>=0.9)) 
			{
###########################################################################
                my $cdcdxx1=$khx1."_".$khx2;
				unless (exists $hash_max_min_1{$cdcdxx1}) 
				{
###########################################################################
				open (OUT2,">TEMD_SEQ_MUSCLE_SEQ_tmp");
				#print OUT2 ">$khx1\n$hash1{$khx1}\n";
				#print OUT2 ">$khx2\n$hash1{$khx2}\n";
				my $subQ_sequences13;  my $subT_sequences23;
				if ($Q_size1>=500) 
				{
					my $subQ_sequences11=substr ($hash1{$khx1}, 0, 200);
					my $subQ_sequences12=substr ($hash1{$khx1}, $Q_size1-200, 200);
					$subQ_sequences13=$subQ_sequences11.$subQ_sequences12;
					my $subT_sequences21=substr ($hash1{$khx2}, 0, 200);
					my $subT_sequences22=substr ($hash1{$khx2}, $T_size1-200, 200);
					$subT_sequences23=$subT_sequences21.$subT_sequences22;

				}
				else
				{
					$subQ_sequences13=$hash1{$khx1};
					$subT_sequences23=$hash1{$khx2};
				}

				print OUT2 ">$khx1\n$subQ_sequences13\n";
				print OUT2 ">$khx2\n$subT_sequences23\n";
				close OUT2;
				my $Q_size1111=length($subQ_sequences13);
				my $T_size1111=length($subT_sequences23);
				my $muscle_soft="$ARGV[3]";
				system ("$muscle_soft -in TEMD_SEQ_MUSCLE_SEQ_tmp -out TEMD_SEQ_MUSCLE_SEQ_tmp_OUT1 -clw -quiet");
				open (IN2,"TEMD_SEQ_MUSCLE_SEQ_tmp_OUT1");
				my $line_muscle_alignment1=0;
				my $totall_xin1=0;
				while (<IN2>) 
				{
					chomp;
					$line_muscle_alignment1++;
					#print $line_muscle_alignment1."\t".$_."\n";
					if ($line_muscle_alignment1>3) 
					{
						if (($line_muscle_alignment1-3)%4==3) 
						{
							my @ppp_muscle1=split(//,$_);
							for (my $kxxx1=0;$kxxx1<@ppp_muscle1; $kxxx1++) 
							{
								$totall_xin1++ if ($ppp_muscle1[$kxxx1]=~/\*/);
							}
						}
					}
				}
				close IN2;
				#print $totall_xin1."\n";
				my $muscle_match111=$totall_xin1/$Q_size1111;
				my $muscle_match222=$totall_xin1/$T_size1111;
				my $last_muscle_ratio1=$muscle_match111*$muscle_match222;
				##print $last_muscle_ratio1."yes\n";
				my $iiiid1=$khx1;  my $iiiid2=$khx2;
				my $iiiid3=$khx1."_".$khx2;
				$hash_martrix1{$iiiid3}=$last_muscle_ratio1;
###########################################################################
                my $reverse_seq_881=reverse ($hash1{$khx2});
				my @pp_reverse1=split(//,$reverse_seq_881);
				my $reverse_seq_882;
				for (my $khx_k1=0;$khx_k1<@pp_reverse1 ;$khx_k1++) 
				{
					if ($pp_reverse1[$khx_k1]=~/\w/gi) 
					{
						if (exists $hash_reverse_complement1{$pp_reverse1[$khx_k1]}) 
						{
							$reverse_seq_882.=$hash_reverse_complement1{$pp_reverse1[$khx_k1]};
						}
						else{$reverse_seq_882.="N";}
					}
				}
				open (OUT22,">TEMD_SEQ_MUSCLE_SEQ_tmp");
				##print OUT22 ">$khx1\n$hash1{$khx1}\n";
				##print OUT22 ">$khx2\n$reverse_seq_882\n";
				my $subQ_sequences113; my $subT_sequences223;
				if ($Q_size1>=500) 
				{
					my $subQ_sequences111=substr ($hash1{$khx1}, 0, 200);
					my $subQ_sequences112=substr ($hash1{$khx1}, $Q_size1-200, 200);
					$subQ_sequences113=$subQ_sequences111.$subQ_sequences112;
					my $subT_sequences221=substr ($reverse_seq_882, 0, 200);
					my $subT_sequences222=substr ($reverse_seq_882, $T_size1-200, 200);
					$subT_sequences223=$subT_sequences221.$subT_sequences222;
				}
				else
				{
					$subQ_sequences113=$hash1{$khx1};
					$subT_sequences223=$reverse_seq_882;
				}
				print OUT22 ">$khx1\n$subQ_sequences113\n";
				print OUT22 ">$khx2\n$subT_sequences223\n";
				close OUT22;
				my $Q_size2222=length($subQ_sequences113);
				my $T_size2222=length($subT_sequences223);
				my $muscle_soft="$ARGV[3]";
				system ("$muscle_soft -in TEMD_SEQ_MUSCLE_SEQ_tmp -out TEMD_SEQ_MUSCLE_SEQ_tmp_OUT1 -clw -quiet");
				open (IN22,"TEMD_SEQ_MUSCLE_SEQ_tmp_OUT1");
				my $line_muscle_alignment1=0;
				my $totall_xin1=0;
				while (<IN22>) 
				{
					chomp;
					$line_muscle_alignment1++;
					#print $line_muscle_alignment1."\t".$_."\n";
					if ($line_muscle_alignment1>3) 
					{
						if (($line_muscle_alignment1-3)%4==3) 
						{
							my @ppp_muscle1=split(//,$_);
							for (my $kxxx1=0;$kxxx1<@ppp_muscle1; $kxxx1++) 
							{
								$totall_xin1++ if ($ppp_muscle1[$kxxx1]=~/\*/);
							}
						}
					}
				}
				close IN22;
				#print $totall_xin1."\n";
				my $muscle_match111=$totall_xin1/$Q_size2222;
				my $muscle_match222=$totall_xin1/$T_size2222;
				my $last_muscle_ratio1=$muscle_match111*$muscle_match222;
				##print "$totall_xin1 $Q_size2222 $T_size2222 $last_muscle_ratio1"."yes11\n";
				#my $iiiid1=$khx1;  my $iiiid2=$khx2;
				#my $iiiid3=$khx1."_".$khx2;
				if ($last_muscle_ratio1>$hash_martrix1{$iiiid3}) 
				{
				    $hash_martrix1{$iiiid3}=$last_muscle_ratio1;
				}
				if ($hash_martrix1{$iiiid3}>=$threshould1) 
				{
					push (@pp_max11, $iiiid2);
				}
				elsif ($hash_martrix1{$iiiid3}<=0.7)
				{
					push (@pp_min11, $iiiid2);
				}
				print XXXXX1 $khx2."\t";
###########################################################################
                }
###########################################################################
			}

			foreach my $fffile1 (@pp_max11) 
			{
				foreach my $fffile2  (@pp_min11) 
				{
					my $cdcd111=$fffile1."_".$fffile2;
					my $cdcd222=$fffile2."_".$fffile1;
					$hash_max_min_1{$cdcd111}++;
					$hash_max_min_1{$cdcd222}++;
				}
			}

		}
	}
	print XXXXX1 "\n";
}
close XXXXX1;
open (OUT4, ">Martrix_all_1.txt"); 
for (my $kkk21=1; $kkk21<$id+1; $kkk21++) 
{
	push (@pp_id1, $kkk21);
	print OUT4 $kkk21."\t";
	for (my $kkk22=1; $kkk22<$id+1; $kkk22++) 
	{
		my $id8=$kkk21."_".$kkk22;
		my $id9=$kkk22."_".$kkk21;

		if ($kkk21==$kkk22) 
		{
			print OUT4 "1\t";
		}
		elsif (exists $hash_martrix1{$id8})
		{
			print OUT4 $hash_martrix1{$id8}."\t";
		}
		elsif (exists $hash_martrix1{$id9})
		{
			print OUT4 $hash_martrix1{$id9}."\t";
		}
		else
		{
			print OUT4 "0.01\t";
		}
	}
	print OUT4 "\n";
}
close OUT4;
open (IN3,"Martrix_all_1.txt");
my %hash_cluster1;
while (<IN3>) 
{
	chomp;
	next if ($_ eq "");
	my @ppxx1=split(/\t/,$_);
	my $number_same1=0;;
	for (my $kkkk1=1;$kkkk1<@ppxx1; $kkkk1++) 
	{
		if ($kkkk1 ne $ppxx1[0]) 
		{
			if ($ppxx1[$kkkk1]>=$threshould1) 
			{
				$number_same1++;
			}
		}
	}
	$hash_cluster1{$number_same1}{$ppxx1[0]}=$_;
}
close IN3;
my %hash_hash1;
foreach my $keys1 (sort {$b<=>$a} keys %hash_cluster1) 
{
	#print $keys1."\t";
	foreach my $keys2 (sort {$a<=>$b} keys %{$hash_cluster1{$keys1}}) 
	{
		unless (exists $hash_hash1{$keys2}) 
		{
			print OUT1 $keys1."\t";  my $unmber_a11; 
		    my @pp_tmp1=split(/\t/,$hash_cluster1{$keys1}{$keys2});
		    for (my $khx881=1;$khx881<@pp_tmp1;$khx881++) 
		    {
				if ($khx881 ne $keys1) 
			    {
				    unless (exists $hash_hash1{$khx881}) 
				    {
				        if ($pp_tmp1[$khx881]>=$threshould1) 
				        {
					        print OUT1 $keys1."_".$khx881."\t";
							$unmber_a11++;
					        $hash_hash1{$khx881}++;
				        }
				    }
			    }
		    }
			print OUT1 "\n";			
		}
	}
}
close OUT1;