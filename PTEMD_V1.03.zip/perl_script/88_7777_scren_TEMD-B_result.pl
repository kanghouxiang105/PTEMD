use strict;
use List::Util 'max';
use List::Util 'min';
open (IN1, "$ARGV[1]".".Result_TE_insertion_position_1.txt");
open (OUT1, ">"."$ARGV[1]".".Result_TE_insertion_position_screen.txt");
open (OUT2, ">"."$ARGV[1]".".Result_TE_insertion_position_screen_result.txt");
open (OUT3, ">$ARGV[0]");
my $length_repeat_region1="30";
my $length_repeat_region2="60";

$/="########################################################################################################################################################################################################################################################################################################################################################################################################################################################";
my $line11=0; my %hash11;
my %hash22; my %hash222;
my %hash_t22; my %hash_t222;

while (<IN1>) 
{
	s/########################################################################################################################################################################################################################################################################################################################################################################################################################################################$//;
	next if ($_ eq "");
	$line11++;
	my @pp1=split(/\n/,$_);
	#print $pp1[3]."\n";
	my @pp2=split(/\s+/,$pp1[3]);
	my @pp4=split(/\s+/,$pp1[1]);
	#my $number=scalar(@pp2);
    my $seqences1=substr ($pp2[0],length($pp2[0])-$length_repeat_region1,$length_repeat_region1);
    my $seqences2=substr ($pp2[7],0,$length_repeat_region1);
    my $seqences11=substr ($pp2[0],length($pp2[0])-$length_repeat_region1-$length_repeat_region1,$length_repeat_region1);
    my $seqences22=substr ($pp2[7],$length_repeat_region1,$length_repeat_region1);
	
	$hash22{$pp4[1]}{$seqences1}{$seqences2}++;
	$hash222{$pp4[1]}{$seqences11}{$seqences22}++;

	my $seqences_t1=substr ($pp2[0],length($pp2[0])-$length_repeat_region2,$length_repeat_region2);
    my $seqences_t2=substr ($pp2[7],0,$length_repeat_region2);
	$hash_t22{$pp4[1]}{$seqences_t1}++; # add
	$hash_t222{$pp4[1]}{$seqences_t2}++; # add	
	#print "$pp4[1] $seqences1 $seqences2 $hash22{$pp4[1]}{$seqences1}{$seqences2}\n";
		if (@pp1>=6) 
		{
			my @pp3=split(//);
	        for (my $khx1=1; $khx1<@pp1 ;$khx1++) 
	        {
		        $hash11{$line11}.=$pp1[$khx1]."\n";
	        }
		}
}
close IN1;
$/="\n";
my $head11="########################################################################################################################################################################################################################################################################################################################################################################################################################################################";
my $totall_number1=0;
foreach my $keys1 (sort {$a<=>$b} keys %hash11) 
{
	print OUT1 $head11."\n";
	print OUT1 $hash11{$keys1}."\n";
}
close OUT1;

$/="########################################################################################################################################################################################################################################################################################################################################################################################################################################################";
open (IN2, $ARGV[1].".Result_TE_insertion_position_screen.txt");
my %hash33;
my %hash44;
my $less_than_two=0;
while (<IN2>) 
{
	s/########################################################################################################################################################################################################################################################################################################################################################################################################################################################$//;
	next if ($_ eq "");
    my @pp11=split(/\n/,$_);
	my @pp22=split(/\s+/,$pp11[1]);
	my @pp33=split(/\s+/,$pp11[3]);
	
	my $seq111=substr ($pp33[0],length($pp33[0])-$length_repeat_region1,$length_repeat_region1);
	my $seq222=substr ($pp33[7],0,$length_repeat_region1);
	my $seq11111=substr ($pp33[0],length($pp33[0])-$length_repeat_region1-$length_repeat_region1,$length_repeat_region1);
	my $seq22222=substr ($pp33[7],$length_repeat_region1,$length_repeat_region1);
	
	my $seq_t881=substr ($pp33[0],length($pp33[0])-$length_repeat_region2,$length_repeat_region2);
	my $seq_t882=substr ($pp33[7],0,$length_repeat_region2);
	
	
	#if (($hash_t22{$pp22[1]}{$seq_t881}==1)      and ($hash_t222{$pp22[1]}{$seq_t882}==1)) 
	#{
	if (($hash22{$pp22[1]}{$seq111}{$seq222}==1) and ($hash222{$pp22[1]}{$seq11111}{$seq22222}==1)) 
	{
		print "$pp22[1] $seq111 $seq222 $hash22{$pp22[1]}{$seq111}{$seq222}\n";
	    $totall_number1++;
		$hash33{$pp22[1]}++;
		$hash44{$pp22[1]}.=$head11."\n";
		$hash44{$pp22[1]}.=$pp22[0]."\t".$pp22[1]."\t"."Number:"."\t".$hash33{$pp22[1]}."\t";
		for (my $kkk1=2;$kkk1<@pp22;$kkk1++) 
		{
			$hash44{$pp22[1]}.=$pp22[$kkk1]."\t";
		}
		$hash44{$pp22[1]}.="\n";
		for (my $kkk2=2;$kkk2<@pp11 ;$kkk2++) 
		{
			$hash44{$pp22[1]}.=$pp11[$kkk2]."\n";
		}
	}
	elsif ($hash22{$pp22[1]}{$seq111}{$seq222}==2)
	{
		$less_than_two++;
	}
    #}
}
$/="\n";
close IN2;  
my $split_data1="########################################################################################################################################################################################################################################################################################################################################################################################################################################################";

foreach my $keys  (sort {$a<=>$b} keys %hash44) 
{
	print OUT2 $hash44{$keys}."\n";
	my @ppkhx81=split(/$split_data1/,$hash44{$keys});
	my %hash_xx1;
	my %hash_xx2;
	my @pp_all1;
	my $totall_number1=0;
	my $print_number1=0;
	foreach my $files1 (@ppkhx81) 
	{
		if ($files1 ne "")
		{
			$totall_number1++;
			my @ppkhx82=split(/\n/,$files1);
			my @ppkhx821=split(/\s+/,$ppkhx82[1]);
			my @ppkhx822=split(/\s+/,$ppkhx82[3]);
			print "$ppkhx822[1] $ppkhx822[6]\n";
			my $left1; my $right1;
			if ($ppkhx822[1]=~/(\d+)/) {$left1=$1;}
			if ($ppkhx822[6]=~/(\d+)/) {$right1=$1;}
			my $distances1=$right1-$left1;
			$hash_xx1{$distances1}++;
			#print $ppkhx82[2]."\n\n";
		}
	}
	foreach my $keys1 (sort {$a<=>$b} keys %hash_xx1) 
	{
		push (@pp_all1, $hash_xx1{$keys1});
	}
	#print " totall: $totall_number1 $hash_xx1{1}\n";
	##if (($totall_number1>0) and ($hash_xx1{"1"}>0)) 
	if ($totall_number1>0)  
	{
		if ($hash_xx1{"1"}/$totall_number1>=0.66) 
		#if ($hash_xx1{"1"}/$totall_number1>=0.1) 
		{
			$hash_xx2{"1"}="8";
		}
		else
		{
			$hash_xx2{"1"}="7";
		}
	}
	my $max=max (@pp_all1);
	my $max_ratio1;
	if (($totall_number1>0) and ($max>0)) 
	{
		$max_ratio1=$max/$totall_number1;
	}
	###########if ($max_ratio1>0.2) {$hash_xx2{"1"}="7";}
	if ($hash_xx2{"1"}== "8") 
	{
	    foreach my $files2 (@ppkhx81) 
	    {
		     if ($files2 ne "")
			 {
				 my @pp_new1=split(/\n/, $files2 );
				 my @pp_new2=split(/\s+/,$pp_new1[1]);
			     my @pp_new3=split(/\s+/,$pp_new1[3]);
			     my $left2; my $right2;
			     if ($pp_new3[1]=~/(\d+)/) {$left2=$1;}
			     if ($pp_new3[6]=~/(\d+)/) {$right2=$1;}
				 if (($right2-$left2)==1) 
				 {
					 $print_number1++;
					 print OUT3 $split_data1."\n";
					 print OUT3 $pp_new2[0]."\t".$pp_new2[1]."\t".$pp_new2[2]."\t".$print_number1."\t";
					 for (my $cdcd1=4; $cdcd1<@pp_new2;$cdcd1++) 
					 {
						 if ($pp_new2[$cdcd1] ne "") 
						 {
						     print OUT3 $pp_new2[$cdcd1]."\t";
						 }
					 }
					 print OUT3 "Breakpoint_Region_Duplication:\tNon_Duplication\n";
					 for (my $cdcd2=2;$cdcd2<@pp_new1 ;$cdcd2++) 
					 {
						 print OUT3 $pp_new1[$cdcd2]."\n";
					 }
					 #print OUT3 "$pp_new2[0] $pp_new2[1] $pp_new2[2] $pp_new2[3]\n";
				 }
				 
			 }
	    }
	}
	elsif ($hash_xx2{"1"}== "7")
	{
		print "yesyesyesyeshere!\n";
	    foreach my $files2 (@ppkhx81) 
	    {
		     if ($files2 ne "")
			 {
				 my @pp_new1=split(/\n/, $files2 );
				 my @pp_new2=split(/\s+/,$pp_new1[1]);
			     my @pp_new3=split(/\s+/,$pp_new1[3]);
			     my $left2; my $right2;
			     if ($pp_new3[1]=~/(\d+)/) {$left2=$1;}
			     if ($pp_new3[6]=~/(\d+)/) {$right2=$1;}
				 my $hahaha1=$right2-$left2;
				 if (($hahaha1<0) or ($hahaha1==1))
				 {
				     if ($hash_xx1{$hahaha1} eq "$max") 
				     {
					     $print_number1++;
						 print OUT3 $split_data1."\n";
					     print OUT3 $pp_new2[0]."\t".$pp_new2[1]."\t".$pp_new2[2]."\t".$print_number1."\t";
					     for (my $cdcd1=4; $cdcd1<@pp_new2; $cdcd1++) 
					     {
						     if ($pp_new2[$cdcd1] ne "") 
						     {
						         print OUT3 $pp_new2[$cdcd1]."\t";
						     }
					     }
						 if ($hahaha1<0) 
						 {
						     my $re_le_881=$hahaha1**2;  my $re_le_882=$re_le_881**0.5;
						     my $dup_seq1=substr ($pp_new3[0],length($pp_new3[0])-$re_le_882-1,$re_le_882+1);
					         if ($dup_seq1 eq "") 
						     {
						        print OUT3 "Breakpoint_Region_Duplication:\tNon_Duplication\n";
					         }
							 else
							 {
						        print OUT3 "Breakpoint_Region_Duplication:\t$dup_seq1\n";

							 }
						 }
						 else
						 {
						        print OUT3 "Breakpoint_Region_Duplication:\tNon_Duplication\n";
					     }
						 for (my $cdcd2=2;$cdcd2<@pp_new1; $cdcd2++) 
					     {
						     print OUT3 $pp_new1[$cdcd2]."\n";
					     }
						 #print OUT3 "$pp_new2[0] $pp_new2[1] $pp_new2[2] $pp_new2[3]\n";
				     }
				 }
			 }
		}
	}
	else
	{
	    print "nonononononno!\n";
	    foreach my $files2 (@ppkhx81) 
	    {
		     if ($files2 ne "")
			 {
				 my @pp_new1=split(/\n/, $files2 );
				 my @pp_new2=split(/\s+/,$pp_new1[1]);
			     my @pp_new3=split(/\s+/,$pp_new1[3]);
			     my $left2; my $right2;
			     if ($pp_new3[1]=~/(\d+)/) {$left2=$1;}
			     if ($pp_new3[6]=~/(\d+)/) {$right2=$1;}
				 my $hahaha1=$right2-$left2;
			 }
		}

	}
}
close OUT2; close OUT3;

