use strict;
#open (IN1,"YN125_all_deletion_ID.txt")||die;
#open (IN2,"YN125_all_deletion_ID.txt_tmp")||die;
open (IN41,"$ARGV[0]")||die;
open (IN42,"$ARGV[1]")||die;
open (OUT41, ">$ARGV[2]"); # single_sequences
open (OUT42, ">$ARGV[3]"); # all_sequences

my %hash44_1; my %hash44_2;
$/="\>";
while (<IN41>) 
{
	s/>$//;
	next if ($_ eq "");
	my @ppxxx4=split(/\n/, $_);
	my $seq44_id1;  my $seq44_anno1;
	if ($ppxxx4[0]=~/([^\s]+)\s+(.+)/) 
	{
		$seq44_id1=$1; $seq44_anno1=$2;
		$hash44_2{$seq44_id1}=$seq44_anno1;
	}
	for (my $kk4=1;$kk4< @ppxxx4 ;$kk4++) 
	{
		$hash44_1{$seq44_id1}.=$ppxxx4[$kk4];
	}
}
close IN41;
$/="\n";
my $TE_CLUSTERS=0;
while (<IN42>) 
{
	chomp;
	next if ($_ eq "");
	my @ppxxx42=split(/\s+/,$_);
	my $number_all_1=scalar(@ppxxx42);
	my $number_all_2=$number_all_1-1;
	my $number_all_3=$ppxxx42[0];
	if ($number_all_2>=2) 
	{
		if ($number_all_3>0) 
		{
			if ($number_all_2/$number_all_3>=0.6) 
			{
				$TE_CLUSTERS++;
				my $single_seq8881;
				if ($ppxxx42[1]=~/(\d+)\_(\d+)/) 
				{
					$single_seq8881=$2;
					print OUT41 ">"."$TE_CLUSTERS\t"."TE_cluster_$TE_CLUSTERS"."\n".$hash44_1{$single_seq8881}."\n";			
				}
				for (my $khx41=1;$khx41<@ppxxx42 ;$khx41++) 
				{
					my $single_seq8882;
					if ($ppxxx42[$khx41]=~/(\d+)\_(\d+)/) 
					{
						$single_seq8882=$2;
						print OUT42 ">"."TE_Cluster".$TE_CLUSTERS."_$khx41"."\t".$hash44_2{$single_seq8882}."\n";
						#print OUT42 $hash44_1{$single_seq8882}."\n";
						print OUT42 $hash44_1{$single_seq8882}."\n";
					}
				}
			}
		}
	}
}
close IN42; close OUT41; close OUT42;