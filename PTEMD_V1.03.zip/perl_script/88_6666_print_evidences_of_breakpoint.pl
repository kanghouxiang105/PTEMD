use strict;
use List::Util 'max';
use List::Util 'min';

open (OUT_FILE1_RESULT,">".$ARGV[2].".Result_TE_insertion_position_1.txt");

my $f88_6666_file1=$ARGV[2].".Result_forward11_22_break.txt";
my $f88_6666_file2=$ARGV[2].".Result_forward11_22_reference.txt";
my $f88_6666_file3=$ARGV[2].".Result_reward11_22_break.txt";
my $f88_6666_file4=$ARGV[2].".Result_reward11_22_reference.txt";

#my @ppa1=glob ("Result_forward11_22_break.txt Result_forward11_22_reference.txt Result_reward11_22_break.txt Result_reward11_22_reference.txt"); 
my @ppa1=glob ("$f88_6666_file1 $f88_6666_file2 $f88_6666_file3 $f88_6666_file4"); 
#my @ppa2=glob ("Result_single_forward_left_break.txt  Result_single_forward_right_break.txt Result_single_reward_left_break.txt Result_single_reward_right_break.txt");

my %hash_reverse_complement1;
$hash_reverse_complement1{A}="T"; $hash_reverse_complement1{T}="A"; $hash_reverse_complement1{G}="C"; $hash_reverse_complement1{C}="G"; $hash_reverse_complement1{N}="N";    
$hash_reverse_complement1{a}="T"; $hash_reverse_complement1{t}="A"; $hash_reverse_complement1{g}="C"; $hash_reverse_complement1{c}="G"; $hash_reverse_complement1{n}="N";

foreach my $file1 (@ppa1) 
{
    my %hash1;
    open (IN1,"$file1")||die;
    open (OUT1,">$file1".".sorted.txt");
    while (<IN1>) 
    {
	    chomp;
	    next if ($_ eq "");
	    my @pp1=split(/\s+/, $_);
		my $tttttteeeee;
		if ($pp1[1]=~/\d+\_([^\s]+)/) 
		{
			$tttttteeeee=$1;
		}
	    $hash1{$tttttteeeee}{$pp1[2]}{$pp1[4]}{$pp1[0]}{$pp1[1]}{$pp1[3]}{$pp1[5]}=$_;
    }
    close IN1;
    foreach my $keys_add1 (sort keys %hash1) 
    {
		foreach my $keys2 (sort keys %{$hash1{$keys_add1}}) 
		{
	    foreach my $keys4 (sort {$a<=>$b} keys %{$hash1{$keys_add1}{$keys2}}) 
	    {
		    foreach my $keys0 (keys %{$hash1{$keys_add1}{$keys2}{$keys4}}) 
		    {
			    foreach my $keys1 (keys %{$hash1{$keys_add1}{$keys2}{$keys4}{$keys0}}) 
			    {
				    foreach my $keys3 (keys %{$hash1{$keys_add1}{$keys2}{$keys4}{$keys0}{$keys1}}) 
				    {
					    foreach my $keys5 (keys %{$hash1{$keys_add1}{$keys2}{$keys4}{$keys0}{$keys1}{$keys3}}) 
					    {
						    print OUT1 $hash1{$keys_add1}{$keys2}{$keys4}{$keys0}{$keys1}{$keys3}{$keys5}."\n";
					    }
				    }
			    }
		    }
	    }
		}
    }
    close OUT1;
}


foreach my $file_c1 (@ppa1) 
{
	my $file_c11=$file_c1.".sorted.txt";
	my $file_c111=$file_c1.".sorted1.txt";
	my $file_c1111=$file_c1.".sorted11.txt";
    open (INX1, "$file_c11"); 	
	open (OUTX1, ">$file_c111");
	while (<INX1>) 
	{
		chomp; next if ($_ eq ""); print OUTX1 $_."\n";		
	}
	print OUTX1 "Chromosomes	1	1	1	1	1"."\n";
	close OUTX1;
    open (INX11, "$file_c111"); 	    
	open (OUTX11, ">$file_c1111");
	my $line1=0;
    my @ppkk1;    my @ppkk2;
    my %hash_k1;  my %hash_k2;
    my $TE_len_1=1860;
    while (<INX11>) 
    {
	    chomp;
	    next if ($_ eq "");
	    $line1++;
	    $hash_k1{$line1}=$_;
	    my @ppx1=split(/\s+/,$_);
	    if ($line1==1) 
	    {
	    	push (@ppkk1, $ppx1[4]); push (@ppkk2, $ppx1[5]); 
	    	$hash_k2{$line1}=$_;
	    }
	    elsif ($line1>=2)
	    {
	    	my $line2=$line1-1;
	    	my @ppx2=split(/\s+/,$hash_k1{$line2});
	    	if (($ppx1[4] eq $ppx2[4]) or ($ppx1[5] eq $ppx2[5])) 
	    	{
		    	push (@ppkk1, $ppx1[4]); push (@ppkk2, $ppx1[5]);
		    	$hash_k2{$line1}=$_;
		    }
		    else
		    {
		    	my %hash1_m1; my %hash2_m2;
		    	my %hash3_m3; my %hash4_m4;
		    	foreach my $file11 (@ppkk1) {$hash1_m1{$file11}++;}
		    	foreach my $file22 (@ppkk2) {$hash2_m2{$file22}++;}
		    	foreach my $cdcd1 (keys %hash1_m1) { my $dd1=$hash1_m1{$cdcd1}; $hash3_m3{$dd1}{$cdcd1}++;}
		    	foreach my $cdcd2 (keys %hash2_m2) { my $dd2=$hash2_m2{$cdcd2}; $hash4_m4{$dd2}{$cdcd2}++;}
		    	my $top21=0; my $top22=0; 
		    	my @pp_taget1; my @pp_taget2;
		    	my @pp_taget3; my @pp_taget4;
		    	my @pp_taget5; my @pp_taget6;
		    	foreach my $ka1 (sort {$b<=>$a} keys %hash3_m3) 
		    	{
		    		foreach my $ka2 (keys %{$hash3_m3{$ka1}}) 
			    	{
			    	    push (@pp_taget1, $ka1); push (@pp_taget2, $ka2);
			    	}
			    }
		    	foreach my $ka3 (sort {$b<=>$a} keys %hash4_m4) 
			    {
			    	foreach my $ka4 (keys %{$hash4_m4{$ka3}}) 
			    	{
			    	    push (@pp_taget3, $ka3); push (@pp_taget4, $ka4);
			    	}
			    }
			    if ($pp_taget1[0] eq $pp_taget1[1]) 
			    {
			    	@pp_taget5=("$pp_taget2[0]","$pp_taget2[1]");
			    }
			    else
			    {
			    	@pp_taget5=("$pp_taget2[0]");
			    }
			    if ($pp_taget3[0] eq $pp_taget3[1]) 
			    {
			    	@pp_taget6=("$pp_taget4[0]","$pp_taget4[1]");
			    }
			    else
			    {
			    	@pp_taget6=("$pp_taget4[0]");
		    	}
		    	my %hash_have1;  my %hash_have2;
		    	foreach my $ffff1 (@pp_taget5) {$hash_have1{$ffff1}++; }
		    	#print "\n";
		    	foreach my $ffff2 (@pp_taget6) {$hash_have2{$ffff2}++; }
		    	#print "\n";
##########################################################################			
                foreach my $kkkeyy1 (sort {$a<=>$b} keys %hash_k2) 
		    	{
			    	my @pppp1=split(/\s+/,$hash_k2{$kkkeyy1});
			    	if (exists $hash_have1{$pppp1[4]}) 
			    	{
			    		if (exists $hash_have2{$pppp1[5]}) 
			    		{
			    			print OUTX11 $hash_k2{$kkkeyy1}."\n";
			    		}
			    	}
                }
##########################################################################									
		    	%hash_k2=();
                $hash_k2{$line1}=$_;
		    	@ppkk1=(); @ppkk2=();
		    	push (@ppkk1, $ppx1[4]); push (@ppkk2, $ppx1[5]);
		    }
	    }
    }
	print OUTX11 "Chromosomes	1	1	1	1	1"."\n";
    close INX11; close OUTX11;
}

############################################################################################
#################print the evidence in to one file##########################################
############################################################################################
############################ ��Ҫ�����ļ�##################################################
##################1�������������ļ���11118.txt.out  #####################################
##################2��ԭʼ�����ļ��� 11118.txt          ####################################
##################3�������������ļ��Լ�TEs�ȶ������������ļ�    ##########################
##################4��8��λ����Ϣ�ļ� 33forward11_22_reference.txt.sorted11.txt  ###########

# put old 111118.txt.out and 111118.txt together 
my %hash_Forward_file1;  my %hash_Forward_file11;     # after packing
my %hash_Reward_file1;   my %hash_Reward_file11;      # after packing
my %hash_Forward_yuanshi1;  my %hash_Reward_yuanshi1; # before packing

$/="\>";
open (IN_SAM_11111, $ARGV[2].".111118_two_files.txt");
open (IN_SAM_22222, $ARGV[2].".222228_two_files.txt");
while (<IN_SAM_11111>) 
{
	s/>$//;
	next if ($_ eq "");
	my @pp11=split(/\n/,$_);
	my $id_1;  my $id_2;
	if ($pp11[0]=~/^([^\s]+)\s+([^\s]+)/) 
	{
		$id_1=$1;  $id_2=$2;
		$hash_Forward_file1{$id_1}=$id_2;
	}
	$hash_Forward_file11{$id_1}=$pp11[1];
	$hash_Forward_yuanshi1{$id_2}=$pp11[2];
}
close IN_SAM_11111;
while (<IN_SAM_22222>) 
{
	s/>$//;
	next if ($_ eq "");
	my @pp11=split(/\n/,$_);
	my $id_1; my $id_2;
	if ($pp11[0]=~/^([^\s]+)\s+([^\s]+)/) 
	{
		$id_1=$1; $id_2=$2;
		$hash_Reward_file1{$id_1}=$2;
	}
	$hash_Reward_file11{$id_1}=$pp11[1];
	$hash_Reward_yuanshi1{$id_2}=$pp11[2];
}
close IN_SAM_22222;

$/="\n";

my %hash_genome1;
$/="\>";
open (IN_genome1, "$ARGV[0]");
while (<IN_genome1>) 
{
	s/>$//;
	next if ($_ eq "");
	my @pp_genome1=split(/\n/,$_);
	my $chr_id1;
	if ($pp_genome1[0]=~/([^\s]+)/) {$chr_id1=$1;}
	for (my $k1=1;$k1<@pp_genome1 ;$k1++) 
	{
		$hash_genome1{$chr_id1}.=$pp_genome1[$k1];
	}
}
close IN_genome1;
$/="\n";
my %hash_TEs_in_genome1; my %hash_TEs_in_genome2;
##open (IN_Tes1,"TE_files.out.out.out");
my $active_te_in_genome_result1="$ARGV[1]".".result1".".result1".".result1";
open (IN_Tes1,"$active_te_in_genome_result1");
#open (IN_Tes1,"$ARGV[1]");
while (<IN_Tes1>) 
{
	chomp;
	next if ($_ eq "");
	my @pp_te1=split (/\t/, $_);
	$hash_TEs_in_genome1{$pp_te1[1]}{$pp_te1[12]}{$pp_te1[0]}{$pp_te1[5]}=0;
	#                      TE_name     chromosomes     + -         strat 
	$hash_TEs_in_genome2{$pp_te1[1]}{$pp_te1[12]}{$pp_te1[0]}{$pp_te1[6]}=0;
	#                      TE_name     chromosomes     + -          end
}
close IN_Tes1;

##################3�������������ļ��Լ�TEs�ȶ������������ļ�    ##########################


############################################################################################

open (IN_forward11_22_break, $ARGV[2].".Result_forward11_22_break.txt.sorted11.txt");
my $line_fb1=0; my %hash_fb1;
my @ppkk1; my @ppkk2; my @ppkk3;
while (<IN_forward11_22_break>) 
{
	    chomp;
	    next if ($_ eq "");
	    $line_fb1++;
	    $hash_fb1{$line_fb1}=$_;
	    my @ppx1=split(/\s+/,$_);
	    if ($line_fb1==1) 
	    {
	    	push (@ppkk1, $ppx1[4]); push (@ppkk2, $ppx1[5]); 
			push (@ppkk3, $line_fb1);
	    	$hash_fb1{$line_fb1}=$_;
	    }
	    elsif ($line_fb1>=2)
	    {
	    	my $line_fb2=$line_fb1-1;
	    	my @ppx2=split(/\s+/,$hash_fb1{$line_fb2});
	    	if (($ppx1[4] eq $ppx2[4]) or ($ppx1[5] eq $ppx2[5])) 
	    	{
		    	push (@ppkk1, $ppx1[4]); push (@ppkk2, $ppx1[5]);
		    	$hash_fb1{$line_fb1}=$_;
				push (@ppkk3, $line_fb1);
		    }
		    else
			{
				my %hash_pp_qian1; my %hash_pp_qian2; 
				my %hash_pp_hou1;  my %hash_pp_hou2;
				my @ppppp_1;       my @ppppp_2; my @ppppp_3;
				foreach my $tar_line1 (@ppkk3) 
				{
					my @tar_data1=split (/\s+/, $hash_fb1{$tar_line1});
					$hash_pp_qian1{$tar_data1[1]}++; $hash_pp_hou1{$tar_data1[3]}++;
					$hash_pp_qian2{$tar_data1[1]}="$tar_data1[0]"."\t"."$tar_data1[4]"."\t"."$tar_data1[6]"."\t"."$tar_data1[7]";
					$hash_pp_hou2{$tar_data1[3]}="$tar_data1[0]"."\t"."$tar_data1[5]"."\t"."$tar_data1[8]"."\t"."$tar_data1[9]";
				    push (@ppppp_1, $tar_data1[4]);  push (@ppppp_2, $tar_data1[5]);
					push (@ppppp_3, $tar_data1[0]);
				}
				my $max_11= max (@ppppp_1); my $min_12= min (@ppppp_2);
				my $tar_seq1=substr ($hash_genome1{$ppppp_3[0]},$max_11-200, 200);
                $tar_seq1=~tr/[a-z]/[A-Z]/;
				my $tar_seq2=substr ($hash_genome1{$ppppp_3[0]},$min_12-1, 200);
				$tar_seq2=~tr/[a-z]/[A-Z]/;
				my $data_len11=18-length($max_11)-length($min_12);
				my $data_len22=" " x $data_len11;
				my $head_11="#" x 440;
				my $head_22="=" x 440;
				my $te_name_111;
				if ($ppx2[1]=~/\d+\_([^\s]+)/) 
				{
					$te_name_111=$1;
				}
#add something here
                my $test_ha_in_references=0;
				my $chromosomes_hahaha1=$ppx2[0];
				for (my $ddddd_aaaa1=$max_11-15; $ddddd_aaaa1<$max_11+15;$ddddd_aaaa1++ ) 
				{
					if (exists $hash_TEs_in_genome1{$te_name_111}{$chromosomes_hahaha1}{"+"}{$ddddd_aaaa1}) 
					{
						$test_ha_in_references++;
					}
				}
				for (my $ddddd_aaaa2=$min_12-15;$ddddd_aaaa2<$min_12+15 ;$ddddd_aaaa2++) 
				{
					if (exists $hash_TEs_in_genome2{$te_name_111}{$chromosomes_hahaha1}{"+"}{$ddddd_aaaa2}) 
					{
						$test_ha_in_references++;
					}
				}
#add something here
                if ($test_ha_in_references==0) 
				{
				print OUT_FILE1_RESULT $head_11."\n";
				print OUT_FILE1_RESULT "TE_Sequences_Name\t$te_name_111\tInsertion_Chromosome\t$ppx2[0]\tPosition_Left_Border\t$max_11\tPosition_Right_Border\t$min_12\tTE_Direction_In_Reference\t\+\t\n";
				print OUT_FILE1_RESULT $head_22."\n";
				print OUT_FILE1_RESULT $tar_seq1."  <"."$max_11".">"." New TE Insertion Region "."<"."$min_12".">"."  ".$tar_seq2."\n";

				my @pp_left_part1;  my @pp_right_part1;
################################## the left part ###################################################
				foreach my $keys1 (keys %hash_pp_qian1) 
				{
					#######print $keys1."\n";
					##XXmy $blast_seq1=$hash_Forward_file11{$keys1};   # blast sequences
					my $blast_seq1= $hash_Forward_file11{$keys1};      # blast sequences qian
					my $length_seq1=length($blast_seq1);
					my @pp_kk1=split(/\t/,$hash_pp_qian2{$keys1});     # 33forward11_22_break.txt.sorted11.txt
					my $ref_move1=$max_11-$pp_kk1[1];                  #  ref_move;
					my $ids_11=$hash_Forward_file1{$keys1};            # ���δ����_���ļ��о�һ�����
					my @pp_kk2=split(/\s+/,$ids_11);                   #sub_ids
					#######print "$ref_move1 $blast_seq1\n";
					foreach my $ffff_1 (@pp_kk2) 
					{
						if ($ffff_1 ne "") 
						{
						    my @pp_kk3=split(/\s+/,$hash_Forward_yuanshi1{$ffff_1});    # yuanshi_file  
							# ��Ŷ�Ӧ����ԭʼ�ļ�
						    my $seq_target1=substr ($pp_kk3[1],$pp_kk3[2],$pp_kk3[3]);  # each_seqs
						    #�˴�target sequence ֱ�Ӿ���һ������
							my $length_seq_target1=length ($seq_target1);
						    my $p_move2=length($seq_target1)-$pp_kk1[3];
						    #$p_move2=0����
							my $seq_target2=substr($seq_target1,0,$length_seq_target1-$p_move2);
							my $empty1=$length_seq1-$length_seq_target1;
						    if (($length_seq_target1-$p_move2-$ref_move1)>0) 
						    {    
                                my $khx2222=" ";
                                my $khx3333=200-$length_seq_target1-length($ffff_1);
					            ##my $khx4444="$khx2222" x ($khx3333-$ref_move1+$p_move2+$empty1-70);
                                ##my $khx6666=70;
					            my $khx4444="$khx2222" x ($khx3333-$ref_move1+$p_move2+$empty1-40);
                                my $khx6666=40;
							    my $khx8888="$khx2222" x $khx6666;	
								
								my $left_part1=$khx8888."$ffff_1"."$khx4444".$seq_target2;
								if (length($left_part1)==200) 
								{
								    push (@pp_left_part1,$left_part1);
								}
					        }	
						}
					}
				}
			    #print "\n";
################################## the left part ###################################################
################################## the right part ##################################################
				foreach my $keys1 (keys %hash_pp_hou1) 
				{
					my $blast_seq1=$hash_Reward_file11{$keys1}; # blast sequences
					my $length_seq1=length($blast_seq1);
					my @pp_kk1=split(/\t/,$hash_pp_hou2{$keys1}); # 33forward11_22_break.txt.sorted11.txt
					my $ref_move1=$pp_kk1[1]-$min_12;              #  ref_move;
					my $ids_11=$hash_Reward_file1{$keys1};
					my @pp_kk2=split(/\s+/,$ids_11);               #sub_ids
					foreach my $ffff_1 (@pp_kk2) 
					{
						if ($ffff_1 ne "") 
						{
						    my @pp_kk3=split(/\s+/,$hash_Reward_yuanshi1{$ffff_1});    # yuanshi_file
						    my $seq_target1=substr ($pp_kk3[1],$pp_kk3[2],$pp_kk3[3]);  # each_seqs
						    my $length_seq_target1=length ($seq_target1);
						    my $p_move2=$pp_kk1[2];
							my $start_111=$pp_kk1[2]-1;
							my $length_print_1=$length_seq_target1-$pp_kk1[2];
						    my $seq_target2=substr($seq_target1,$start_111,$length_print_1);
							my $empty1=$length_seq1-$length_seq_target1;
						    if (($length_seq_target1-$pp_kk1[2]+$ref_move1)>0) 
						    {    
                                #my $sssss_1=200+33+length($max_11)+length($min_12)+$ref_move1;
                                my $sssss_1=33+length($max_11)+length($min_12)+$ref_move1;
								my $khx2222=" ";
							    my $khx3333="$khx2222" x $sssss_1;	
								my $khx4444=150-length($seq_target2);
								my $khx5555=" " x $khx4444;
								#print $khx3333.$seq_target2.$khx5555.$ffff_1."\n";
								#my $right_part1=$khx3333.$seq_target2.$khx5555.$ffff_1;
								my $right_part1=$khx3333.$seq_target2.$khx5555.$ffff_1;
								push (@pp_right_part1,$right_part1);
								#push (@pp_right_part1,$left_part1);
					        }	
						}
					}
				}
				#print "\n";
################################## the right part ##################################################
				if ((@pp_left_part1+@pp_right_part1)>2) 
				{
				if (@pp_left_part1>=1 and @pp_right_part1>=1) 
				{
				if (@pp_left_part1>=@pp_right_part1) 
				{
					for (my $khxcd1=0;$khxcd1<@pp_left_part1 ;$khxcd1++) 
					{
						print OUT_FILE1_RESULT $pp_left_part1[$khxcd1].$pp_right_part1[$khxcd1]."\n";
					}
				}
				elsif (@pp_left_part1<@pp_right_part1)
				{
					for (my $khxcd2=0;$khxcd2<@pp_left_part1 ;$khxcd2++) 
					{
						print OUT_FILE1_RESULT $pp_left_part1[$khxcd2].$pp_right_part1[$khxcd2]."\n";
					}
				}
				for (my $khxcd3=@pp_left_part1;$khxcd3<@pp_right_part1 ;$khxcd3++) 
				{
					my $khx2222222=" " x 200;
					print OUT_FILE1_RESULT $khx2222222.$pp_right_part1[$khxcd3]."\n";
				}
				}
                }
				}

#######################################################################				
				
				%hash_fb1=();
                $hash_fb1{$line_fb1}=$_;
		    	@ppkk1=(); @ppkk2=(); @ppkk3=();
		    	push (@ppkk1, $ppx1[4]); push (@ppkk2, $ppx1[5]);
				push (@ppkk3, $line_fb1);
#######################################################################				
			}
		}
}
close IN_forward11_22_break;
#=cut
#######################################################################				
#######################################################################				
open (IN_reward11_22_break, $ARGV[2].".Result_reward11_22_break.txt.sorted11.txt");
my $line_fb1=0; my %hash_fb1;
my @ppkk1; my @ppkk2; my @ppkk3;
while (<IN_reward11_22_break>) 
{
	    chomp;
	    next if ($_ eq "");
	    $line_fb1++;
	    $hash_fb1{$line_fb1}=$_;
	    my @ppx1=split(/\s+/,$_);
	    if ($line_fb1==1) 
	    {
	    	push (@ppkk1, $ppx1[4]); push (@ppkk2, $ppx1[5]); 
			push (@ppkk3, $line_fb1);
	    	$hash_fb1{$line_fb1}=$_;
	    }
	    elsif ($line_fb1>=2)
	    {
	    	my $line_fb2=$line_fb1-1;
	    	my @ppx2=split(/\s+/,$hash_fb1{$line_fb2});
	    	if (($ppx1[4] eq $ppx2[4]) or ($ppx1[5] eq $ppx2[5])) 
	    	{
		    	push (@ppkk1, $ppx1[4]); push (@ppkk2, $ppx1[5]);
		    	$hash_fb1{$line_fb1}=$_;
				push (@ppkk3, $line_fb1);
		    }
		    else
			{
				my %hash_pp_qian1; my %hash_pp_qian2; 
				my %hash_pp_hou1;  my %hash_pp_hou2;
				my @ppppp_1;       my @ppppp_2; my @ppppp_3;
				foreach my $tar_line1 (@ppkk3) 
				{
					my @tar_data1=split (/\s+/, $hash_fb1{$tar_line1});
					$hash_pp_qian1{$tar_data1[1]}++; $hash_pp_hou1{$tar_data1[3]}++;
					$hash_pp_qian2{$tar_data1[1]}="$tar_data1[0]"."\t"."$tar_data1[4]"."\t"."$tar_data1[6]"."\t"."$tar_data1[7]";
					$hash_pp_hou2{$tar_data1[3]}="$tar_data1[0]"."\t"."$tar_data1[5]"."\t"."$tar_data1[8]"."\t"."$tar_data1[9]";
				    push (@ppppp_1, $tar_data1[4]);  push (@ppppp_2, $tar_data1[5]);
					push (@ppppp_3, $tar_data1[0]);
				}
				my $min_11= min (@ppppp_1); my $max_12= max (@ppppp_2);
				
				####my $tar_seq1=substr ($hash_genome1{$ppppp_3[0]},$max_12-200-1, 200);
				my $tar_seq1=substr ($hash_genome1{$ppppp_3[0]},$max_12-200, 200);
			    $tar_seq1=~tr/[a-z]/[A-Z]/;
				my $tar_seq2=substr ($hash_genome1{$ppppp_3[0]},$min_11-1, 200);
				$tar_seq2=~tr/[a-z]/[A-Z]/;
				my $data_len11=18-length($max_12)-length($min_11);
				my $data_len22=" " x $data_len11;
				my $head_11="#" x 440;
				my $head_22="=" x 440;
				my $te_name_111;
				if ($ppx2[1]=~/\d+\_([^\s]+)/) 
				{
					$te_name_111=$1;
				}
#add something here
                my $test_ha_in_references1=0;
				my $chromosomes_hahaha11=$ppx2[0];
				for (my $ddddd_aaaa1=$max_12-15; $ddddd_aaaa1<$max_12+15;$ddddd_aaaa1++ ) 
				{
					if (exists $hash_TEs_in_genome2{$te_name_111}{$chromosomes_hahaha11}{"-"}{$ddddd_aaaa1}) 
					{
						$test_ha_in_references1++;
					}
				}
				for (my $ddddd_aaaa2=$min_11-15;$ddddd_aaaa2<$min_11+15 ;$ddddd_aaaa2++) 
				{
					if (exists $hash_TEs_in_genome2{$te_name_111}{$chromosomes_hahaha11}{"-"}{$ddddd_aaaa2}) 
					{
						$test_ha_in_references1++;
					}
				}
#add something here

				
				if ($test_ha_in_references1==0) 
				{
				print OUT_FILE1_RESULT $head_11."\n";
				print OUT_FILE1_RESULT "TE_Sequences_Name\t$te_name_111\tInsertion_Chromosome\t$ppx2[0]\tPosition_Left_Border\t$max_12\tPosition_Right_Border\t$min_11\tTE_Direction_In_Reference\t\-\t\n";
				print OUT_FILE1_RESULT $head_22."\n";
				print OUT_FILE1_RESULT $tar_seq1."  <"."$max_12".">"." New TE Insertion Region "."<"."$min_11".">"."  ".$tar_seq2."\n";

				my @pp_left_part1;  my @pp_right_part1;
################################## the left part ###################################################
# in the end
				foreach my $keys1 (keys %hash_pp_qian1) 
				{
					my $blast_seq1=$hash_Forward_file11{$keys1};    # blast sequences
					my $length_seq1=length($blast_seq1);
					my @pp_kk1=split(/\t/,$hash_pp_qian2{$keys1});  #  33forward11_22_break.txt.sorted11.txt
					my $unmatched1=length($blast_seq1)-$pp_kk1[3];
					my $ref_move1=$pp_kk1[1]-$min_11;               #  ref_move;
					my $ids_11=$hash_Forward_file1{$keys1};
					my @pp_kk2=split(/\s+/,$ids_11);                #sub_ids
					foreach my $ffff_1 (@pp_kk2) 
					{
						if ($ffff_1 ne "") 
						{
							my @pp_kk3=split(/\s+/,$hash_Forward_yuanshi1{$ffff_1});  # yuanshi_file
							my $seq_target1=substr($pp_kk3[1], $pp_kk3[2], $pp_kk3[3]-$unmatched1);
							my $length_seq_target1=length ($seq_target1);
							my $blast_seq_move1=length($blast_seq1)-$pp_kk1[3];

							my $empty=" " x $ref_move1;
							my $seq_target1_reverse=reverse ($seq_target1);
							my @pp_reverse_left_11=split(//,$seq_target1_reverse);
							my $seq_target1_reverse_complement1;
							for (my $cdc1=0;$cdc1<@pp_reverse_left_11 ;$cdc1++) 
							{
								$seq_target1_reverse_complement1.=$hash_reverse_complement1{$pp_reverse_left_11[$cdc1]};
							}							
							my $seq_target2=$empty.$seq_target1_reverse_complement1;
							my $empty22=length($max_12)+length($min_11)+33; 
							my $empty33=" " x $empty22;
							my $seq_target33=$empty33.$seq_target2;
							my $empty44=200-length($seq_target33);
							my $empty55=" " x $empty44;
							my $seq_target44=$seq_target33.$empty55.$ffff_1;
							push (@pp_left_part1, $seq_target44);
						}
					}
				}
			    #print "\n";
################################## the left part ###################################################
################################## the right part ##################################################
                #my %hash_Reward_file1;   my %hash_Reward_file11;
				#my %hash_Reward_yuanshi1;
				foreach my $keys1 (keys %hash_pp_hou1) 
				{
					my $blast_seq1=$hash_Reward_file11{$keys1};     #  blast sequences
					my @pp_kk1=split(/\t/,$hash_pp_hou2{$keys1});   #  33forward11_22_break.txt.sorted11.txt
					my $unmatched1=$pp_kk1[2];
					my $ref_move1=$max_12-$pp_kk1[1];               #  ref_move;
					my $ids_11=$hash_Reward_file1{$keys1};
					my @pp_kk2=split(/\s+/,$ids_11);                #  sub_ids
					foreach my $ffff_1 (@pp_kk2) 
					{
						if ($ffff_1 ne "") 
						{
						    my @pp_kk3=split(/\s+/,$hash_Reward_yuanshi1{$ffff_1});    # yuanshi_file
						    my $seq_target1=substr ($pp_kk3[1],$pp_kk3[2],$pp_kk3[3]);
                            ####my $seq_target2=substr ($seq_target1,$unmatched1,length($seq_target1)-$unmatched1);
                            my $seq_target2=substr ($seq_target1,$unmatched1-1,length($seq_target1)-$unmatched1);
							my $seq_target1_reverse=reverse ($seq_target2);
							my @seq_target1_complement1=split(//,$seq_target1_reverse);
							my $seq_target1_reverse_complement1;
							for (my $kkkkk1=0;$kkkkk1<@seq_target1_complement1 ;$kkkkk1++) 
							{
								$seq_target1_reverse_complement1.=$hash_reverse_complement1{$seq_target1_complement1[$kkkkk1]};
							}
							my $empty11=(200-$ref_move1-length($seq_target1_reverse));
							##my $empty22=$empty11-50-length($ffff_1);
							my $empty22=$empty11-40-length($ffff_1);
							my $empty33=" " x $empty22;
							##my $empty44=" " x 50;
							my $empty44=" " x 40;
							my $tail11=" " x $ref_move1;
							my $right_part11=$empty44.$ffff_1.$empty33.$seq_target1_reverse_complement1.$tail11;
							if (length($seq_target1_reverse_complement1)>=4) 
							{
								if (length ($right_part11)==200) 
								{
							        push (@pp_right_part1,$right_part11);
								}
							}
						}
					}
				}
################################## the right part ##################################################
                #if ((@pp_right_part1+@pp_left_part1)>=5) 
                if ((@pp_right_part1+@pp_left_part1)>2) 
				{
				if (@pp_right_part1>=1 and @pp_left_part1>=1) 
				{
				if (@pp_right_part1>=@pp_left_part1) 
				{
					for (my $khxcd1=0;$khxcd1<@pp_right_part1 ;$khxcd1++) 
					{
						print OUT_FILE1_RESULT $pp_right_part1[$khxcd1].$pp_left_part1[$khxcd1]."\n";
					}
				}
				elsif (@pp_right_part1<@pp_left_part1)
				{
					for (my $khxcd2=0;$khxcd2<@pp_right_part1 ;$khxcd2++) 
					{
						print OUT_FILE1_RESULT $pp_right_part1[$khxcd2].$pp_left_part1[$khxcd2]."\n";
					}
				    for (my $khxcd3=@pp_left_part1;$khxcd3<@pp_left_part1 ;$khxcd3++) 
				    {
					    my $khx2222222=" " x 200;
					    print OUT_FILE1_RESULT $khx2222222.$pp_left_part1[$khxcd3]."\n";
				    }
				}
                }
                }
				}
#######################################################################				
				
				%hash_fb1=();
                $hash_fb1{$line_fb1}=$_;
		    	@ppkk1=(); @ppkk2=(); @ppkk3=();
		    	push (@ppkk1, $ppx1[4]); push (@ppkk2, $ppx1[5]);
				push (@ppkk3, $line_fb1);
#######################################################################				
			}
		}
}
close IN_reward11_22_break;
#######################################################################				
#######################################################################	

##################4��8��λ����Ϣ�ļ� 33forward11_22_reference.txt.sorted11.txt  ###########

close OUT_FILE1_RESULT;


