use strict;
## go into the files to get the _D files
my %hash_hash1;
$/="\>";
#open (INXXX1,"toplevel.fasta")||die;
open (INXXX1,"$ARGV[0]")||die;
while (<INXXX1>) 
{
	s/>$//;
	my @ppxx1=split(/\n/,$_);
	my $chr_namex1;
	if ($ppxx1[0]=~/([^\s]+)\s*/) 
	{
		$chr_namex1=$1;
	}
	for (my $kk1=1;$kk1<@ppxx1; $kk1++) 
	{
		$hash_hash1{$chr_namex1}.=$ppxx1[$kk1];
	}
}
close INXXX1;
$/="\n";
my $haha_2="./".$ARGV[1]."/"."*_D";
print "$haha_2\n";
#my @ppx1=glob ("./YN125_TED-A1/*_D");
my @ppx1=glob ("$haha_2");
foreach my $filess1 (@ppx1) 
{
	print $filess1."\n";
}
my $out_file2="$ARGV[2]"."_all_deletion_ID.txt";
open (OUT1_2,">$out_file2");
my $gene_index1=0;
foreach my $filexx1 (@ppx1) 
{
	#print $filexx1."\n";
	open (INXXX2,"$filexx1")||die;
    $/="####################################################################################################";
    while (<INXXX2>) 
    {
	    my @pp3=split(/\n/,$_);
	    next if ($pp3[0]=~/\#\#\#\#\#\#\#\#\#\#/);
	    my @pp4=split(/\s+/,$pp3[1]);
	    my $chr11=$pp4[7]; my $start11=$pp4[9]; my $end11=$pp4[10];
        #print  OUT1 $chr11."\t".$start11."\t".$end11."\t";
		my $length11=($end11-$start11)^2^0.5;
		if ($length11>=100) 
		{
		    #print OUT1 $chr11."\t".$start11."\t".$end11."\n";
			$gene_index1++; my $length881=$end11-$start11-1;
			my $new_start1=$start11+1; my $new_end1=$end11-1;
			my $seq_khx1=substr($hash_hash1{$chr11}, $start11, $length881);
			print OUT1_2 ">".$gene_index1." ".$chr11." ".$new_start1." ".$new_end1." ".$length881."\n";
			print OUT1_2 $seq_khx1."\n";
		}
	}
	close INXXX2;
}
close OUT1_2;
