use strict;
my %hash_reverse_complement1;
$hash_reverse_complement1{A}="T"; $hash_reverse_complement1{T}="A"; $hash_reverse_complement1{G}="C"; $hash_reverse_complement1{C}="G"; $hash_reverse_complement1{N}="N";    
$hash_reverse_complement1{a}="T"; $hash_reverse_complement1{t}="A"; $hash_reverse_complement1{g}="C"; $hash_reverse_complement1{c}="G"; $hash_reverse_complement1{n}="N";
#my $muscle_path1="/media/data2/the_TE_project/test_bwa/TEMD_software/ATEMD-new2/muscle3.8.31_i86linux64";
my $muscle_soft="$ARGV[0]";
open (IN1,"$ARGV[1]");
open (OUTX1,">$ARGV[2]");
$/="\>";
my %hash11;
while (<IN1>) 
{
	s/>$//;
	next if ($_ eq "");
	my @pp1=split(/\n/, $_);
	my $seq1;
	for (my $k1=1; $k1<@pp1 ; $k1++) 
	{
		$seq1.=$pp1[$k1];
	}
	my @pp2=split(/\s+/, $pp1[0]);
	my $length_seq1=length ($seq1);
	if ($pp2[0]=~/TE\_Cluster(\d+)\_(\d+)/) 
	{
		my $id11=$1;  my $id22=$2;
		$hash11{$id11}{$length_seq1}{$id22}=$seq1;
	}
}
close IN1;
$/="\n";

my %hash_easy_clustered_1;

foreach my $keys1 (sort {$a<=>$b}  keys %hash11) 
{
	my %hash22; my $add_line1=0;
	foreach my $keys2 (keys %{$hash11{$keys1}}) 
	{
		foreach my $keys3 (sort {$a<=>$b} keys %{$hash11{$keys1}{$keys2}}) 
		{
			$add_line1++;
			$hash22{$add_line1}=$hash11{$keys1}{$keys2}{$keys3};
		}
	}
	my $ID_last1;
	for (my $k2=1; $k2<$add_line1+1; $k2++ ) 
	{
	    my $number_perfect=0;  
		for (my $kk2=1;$kk2<$add_line1+1 ;$kk2++) 
		{
			my $seq_each1=$hash22{$k2};
			my $seq_each2=$hash22{$kk2};
			open (OUT1,">TEMD_SEQ_MUSCLE_SEQ2_tmp");
			print OUT1 ">"."$k2"."\n".$seq_each1."\n";
		    print OUT1 ">"."$kk2"."\n".$seq_each2."\n";
			close OUT1;
		    system ("$muscle_soft -in TEMD_SEQ_MUSCLE_SEQ2_tmp -out TEMD_SEQ_MUSCLE_SEQ2_tmp_OUT2 -clw");
			open (IN22,"TEMD_SEQ_MUSCLE_SEQ2_tmp_OUT2");
			my $line_muscle_alignment1=0;
		    my $seq_seq11;
			my $ID_ID1;
			while (<IN22>) 
		    {
			    chomp;
			    $line_muscle_alignment1++;
				if ($line_muscle_alignment1>3) 
			    {
					
					if (($line_muscle_alignment1-3)%4==1) 
					{
						if ($_=~/([^\s]+\s*)/) 
						{
							$ID_ID1=$1;
							#print OUTX1 $_."\n";
						}
					}
					if (($line_muscle_alignment1-3)%4==3)
					{
						my $empty11=length($ID_ID1);
						#print OUTX1 $empty11."\n";
						my $length111=length($_)-$empty11;
						my $seq_hahahaha1=substr($_, $empty11, $length111);
						$seq_seq11.=$seq_hahahaha1;
					}
				}
			}
			close IN22;
			#print OUTX1 $seq_seq11."\n";
			my @ppxx11=split(//, $seq_seq11 );
			my $totall_number1=0;
			for (my $khxcd1=0;$khxcd1<@ppxx11 ;$khxcd1++) 
			{
				$totall_number1++ if ($ppxx11[$khxcd1]=~/\*/);
			}
			my $seq_length11=length($seq_each1);
			if ($seq_length11>0) 
			{
				if (($totall_number1/$seq_length11)>=0.85) 
				{
					my $linshi_81;  my $linshi_82;
                    if ($seq_seq11=~/^(.{40})/)
			        {
						$linshi_81=$1;
						if ( $seq_seq11=~/(.{40})$/ ) 
						{
							$linshi_82=$1;
							my @pp_linshi_81=split (//,$linshi_81);
				            my @pp_linshi_82=split (//,$linshi_82);
							my $data_111=0;  my $data_112=0;
							for (my $cdcd1=0;$cdcd1<@pp_linshi_81 ;$cdcd1++) 
							{
								$data_111++ if ($pp_linshi_81[$cdcd1]=~/\*/);
							}
							for (my $cdcd2=0;$cdcd2<@pp_linshi_82 ;$cdcd2++) 
							{
								$data_112++ if ($pp_linshi_82[$cdcd2]=~/\*/);
							}
							if (($data_111>=38) and ($data_112>=38)) 
							{
							    $number_perfect++;
					            #print OUTX1 "$keys1 $k2 $kk2 $number_perfect\n";
							}
						}
			        }
				    else 
					{
						#print OUTX1 "not".$seq_seq11."\n";
					}
				}
				elsif (($totall_number1/$seq_length11)<0.85)
				{
					#print OUTX1 "$k2 $kk2\n";
					open (OUT2,">TEMD_SEQ_MUSCLE_SEQ2_tmp");
			        #print OUT1 ">"."$k2"."\n".$seq_each1."\n";
		            #print OUT1 ">"."$kk2"."\n".$seq_each2."\n";
					my $reverse_seq1=reverse ($seq_each2);
					my @pp_reverse1=split($reverse_seq1);
					my $reverse_seq2;
					for (my $khxcd22=0;$khxcd22<@pp_reverse1; $khxcd22++) 
					{
						if (exists $hash_reverse_complement1{$pp_reverse1[$khxcd22]}) 
						{
							$reverse_seq2.=$hash_reverse_complement1{$pp_reverse1[$khxcd22]};
						}
						else
						{
							$reverse_seq2.="N";
						}
					}
		            #print OUT1 ">"."$kk2"."\n".$reverse_seq2."\n";
					close OUT1;
		            system ("$muscle_soft -in TEMD_SEQ_MUSCLE_SEQ2_tmp -out TEMD_SEQ_MUSCLE_SEQ2_tmp_OUT2 -clw");
			        open (IN33,"TEMD_SEQ_MUSCLE_SEQ2_tmp_OUT2");
			        my $line_muscle_alignment2=0;
					my $seq_seq22;
					my $ID_ID2;
					while (<IN33>) 
					{
			            chomp;
			            $line_muscle_alignment2++;
				        if ($line_muscle_alignment2>3) 
			            {
					        if (($line_muscle_alignment2-3)%4==1) 
					        {
						        if ($_=~/([^\s]+\s*)/) 
						        {
							        $ID_ID2=$1;
						        }
					        }
					        elsif (($line_muscle_alignment2-3)%4==3)
					        {
								my $empty22=length($ID_ID2);
						        my $length222=length($_)-$empty22;
						        my $seq_hahahaha2=substr($_, $empty22, $length222);
						        $seq_seq22.=$seq_hahahaha2;
					        }
				        }
					}
 
					

					my $linshi_881;  my $linshi_882;
                    if ($seq_seq22=~/^(.{40})/)
			        {
						$linshi_881=$1;
						if ( $seq_seq22=~/(.{40})$/ ) 
						{
							$linshi_882=$1;
							my @pp_linshi_881=split (//,$linshi_881);
				            my @pp_linshi_882=split (//,$linshi_882);
							my $data_113=0;  my $data_114=0;
							for (my $cdcd3=0;$cdcd3<@pp_linshi_881 ;$cdcd3++) 
							{
								$data_113++ if ($pp_linshi_881[$cdcd3]=~/\*/);
							}
							for (my $cdcd4=0;$cdcd4<@pp_linshi_882 ;$cdcd4++) 
							{
								$data_114++ if ($pp_linshi_882[$cdcd4]=~/\*/);
							}
							if (($data_113>=38) and ($data_114>=38)) 
							{
							    $number_perfect++;
					            #print OUTX1 "$k2 $kk2 $number_perfect\n";
						        #print OUTX1 $seq_seq11."\n";
							}
						}
			        }
				}
			}
		}	
		my $fit_or_not;
		#print "$number_perfect $add_line1\n";
		if ($add_line1>0) 
		{
			if ($number_perfect/$add_line1>=0.6) 
			{
				$fit_or_not="yes_yes";
			}
		}
		if ($fit_or_not=~/yes\_yes/)
		{
			#print OUTX1 "$keys1 here is right: $k2\n";
			$ID_last1=$k2;
	        my $ID_last1_seq=$hash22{$ID_last1};
	        ####print OUTX1 ">$keys1"."\t"."TE_cluster_$keys1\n";
	        ####print OUTX1 $ID_last1_seq."\n";
			$hash_easy_clustered_1{$keys1}=$ID_last1_seq;
			last;
		}
	}
}

foreach my $keys1 (sort {$a<=>$b}  keys %hash11) 
{
	if (exists $hash_easy_clustered_1{$keys1}) 
	{
		print OUTX1 ">".$keys1."\t"."TE_cluster_".$keys1."\n";
		print OUTX1 $hash_easy_clustered_1{$keys1}."\n";
	}
	else
	{
		my $inserct1=0;
		foreach my $keys2 ( keys %{$hash11{$keys1}}) 
		{
			foreach my $keys3 (sort {$a<=>$b} keys %{$hash11{$keys1}{$keys2}}) 
			{
				$inserct1++;
				if ($inserct1==1) 
				{
		            print OUTX1 ">".$keys1."\t"."TE_cluster_".$keys1."\n";
		            print OUTX1 $hash11{$keys1}{$keys2}{$keys3}."\n";
				}
			}
		}
	}
}
close OUTX1;