####################################################################################
## PTEMD-B.pl
## The purpose of this program is to get the TEs insertion Landscape in the reference genome
## Vision: 1.0.2
## Developer: Houxiang Kang
## Time: 2014-11-01
####################################################################################
#use strict;
use Getopt::Std;
use File::Spec;

######====================================================================
######====================================================================
####################################################################################
use Getopt::Std;
use File::Spec;
#getopts "o:s:i:e:a:l:";
getopts "o:i:t:1:2:";
#if ((!defined  $opt_i)|| (! defined  $opt_s) || (!defined  $opt_o)) {
if ((!defined  $opt_i)||  (!defined  $opt_t) || (!defined  $opt_1) || (!defined  $opt_o) ) {
	die "************************************************************************
	Usage: PTEMD-B.pl -i reference_genome.fasta -t TEs_sequences.fasta -1 file1.fastq -o TE_insertion_distributions.txt
	  -h : help and usage.
	  -2 : the second fastq file (default no_file)
************************************************************************\n";
}
my $Reference_genome1 = $opt_i;
my $Active_tes_fasta1 = $opt_t;
my $Fastq_file1 = $opt_1;
my $Fastq_file2 = (defined  $opt_2) ?  $opt_2 : no_file;
my $Out_file1 = $opt_o;

#print "$Reference_genome1\n$Active_tes_fasta1\n$Fastq_file1\n$Out_file1\n\n";
#print "$Fastq_file2\n";

$/="\>";
open (Single_TE_seq1, $Active_tes_fasta1);
my $pp_te_seq_number11=0;
while (<Single_TE_seq1>) {s/>$//; next if ($_ eq ""); $pp_te_seq_number11++; }
if ($pp_te_seq_number11>1) 
{ die "\n\n########################\nFailed to run the PTEMD program!!!\nOnly one TE (transposable element) sequence is permitted each time\nPlease Check the input TE sequence file of $Active_tes_fasta1\n########################\n";}
$/="\n";

#print "Running.....\n";
######====================================================================
######====================================================================

my $path_curf = File::Spec->rel2abs(__FILE__);
my ($vol_p, $dirs_p, $file_p) = File::Spec->splitpath($path_curf);

my $software_pathdir_11="$dirs_p";
my $Pindel_blat_blast_bwa_paths="$software_pathdir_11"."All_Software_paths_for_ATEMD.txt";
my $Pindel_sam2pindel_path;
my $Pindel_path;
my $blat_path;
my $formatdb_path;
my $blastall_path;
my $bwa_path;

print $software_pathdir_11."\n";
print $Pindel_blat_blast_bwa_paths."\n";

open (IIIN1,"$Pindel_blat_blast_bwa_paths");
while (<IIIN1>) 
{
	#print $_;
	chomp; next if ($_ eq "");
	if ($_=~/Pindel_sam2pindel\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi) {$Pindel_sam2pindel_path=$1;}
	elsif ($_=~/Pindel_x86_64\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi){$Pindel_path=$1;}
	elsif ($_=~/Blat\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi){$blat_path=$1;}
	elsif ($_=~/Blast_formatdb\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi){$formatdb_path=$1;}
	elsif ($_=~/Blast_blastall\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi){$blastall_path=$1;}
	elsif ($_=~/BWA\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi){$bwa_path=$1;}
}
close IIIN1;

#print "sam $Pindel_sam2pindel_path\n pindel $Pindel_path\n";
#print "blat $blat_path\n";
#print "formatdb $formatdb_path\n blast $blastall_path\n BWA $bwa_path\n";
###########################################################################
my $add_idss;
if ($Active_tes_fasta1=~/([^\/]+)$/) {$add_idss1=$1;}
if ($Fastq_file1=~/([^\/]+)$/) {$add_idss2=$1;}
if ($Fastq_file2=~/([^\/]+)$/) {$add_idss3=$1;}

#print "herehere $add_idss1\n";

my $sam_out_file1="./"."$add_idss1".".$add_idss2".".sam";
my $sam_out_file2="./"."$add_idss1".".$add_idss3".".sam";

print "haha $sam_out_file1 $sam_out_file2\n";
system ("$bwa_path index $Active_tes_fasta1");
system ("$bwa_path mem $Active_tes_fasta1 $Fastq_file1 | grep [0-9]M  >   $sam_out_file1");
if ($Fastq_file2 ne "no_file") {system ("$bwa_path mem $Active_tes_fasta1 $Fastq_file2 | grep [0-9]M > $sam_out_file2");}
#==========================================================================
#the real path for the six perl script:
#my $path_883333_perl="$software_pathdir_11"."perl_script"."/"."883333find_near_type2_plan.pl";
#my $path_884444_perl="$software_pathdir_11"."perl_script"."/"."884444_evidece_files_and_blast_files.pl";
#my $path_885555_perl="$software_pathdir_11"."perl_script"."/"."885555blast_to_genome.pl";
#my $path_886666_perl="$software_pathdir_11"."perl_script"."/"."886666blast_result_screennew.pl";
#my $path_887777_perl="$software_pathdir_11"."perl_script"."/"."887777print_evidences_of_breakpoint.pl";
#my $path_888888_perl="$software_pathdir_11"."perl_script"."/"."888888_scren_TEMD-B_result.pl";
#my $screen_blast_result_path="$software_pathdir_11"."perl_script"."/"."EblastN.pl";

my $path_883333_perl="$software_pathdir_11"."perl_script"."/"."88_3333_bwa_fastq_and_seq_to_ID.pl";
my $path_884444_perl="$software_pathdir_11"."perl_script"."/"."88_4444_blast_bwa_alignment_to_genome.pl";
my $path_885555_perl="$software_pathdir_11"."perl_script"."/"."88_5555_BWA_result_screennew.pl";
my $path_886666_perl="$software_pathdir_11"."perl_script"."/"."88_6666_print_evidences_of_breakpoint.pl";
my $path_887777_perl="$software_pathdir_11"."perl_script"."/"."88_7777_scren_TEMD-B_result.pl";
#my $path_888888_perl="$software_pathdir_11"."perl_script"."/"."888888_scren_TEMD-B_result.pl";
my $screen_blast_result_path="$software_pathdir_11"."perl_script"."/"."EblastN.pl";


###########################################################################
my $bwa_index_filess=0;
my $bwa_index_file1="$Reference_genome1".".amb";
my $bwa_index_file2="$Reference_genome1".".ann";
my $bwa_index_file3="$Reference_genome1".".bwt";
my $bwa_index_file4="$Reference_genome1".".pac";
my $bwa_index_file5="$Reference_genome1".".sa";
if (-e $bwa_index_file1) {$bwa_index_filess++;}
if (-e $bwa_index_file2) {$bwa_index_filess++;}
if (-e $bwa_index_file3) {$bwa_index_filess++;}
if (-e $bwa_index_file4) {$bwa_index_filess++;}
if (-e $bwa_index_file5) {$bwa_index_filess++;}
if ($bwa_index_filess<5) 
{
	die "Please format the reference genome sequences use Pre_TEMD-B.pl before running PTEMD-B.pl program\n";
}
###########################################################################
#==========================================================================
system ("perl $path_883333_perl $Active_tes_fasta1 $sam_out_file1 $sam_out_file2 $add_idss1");

# output file 111118.txt 222228.txt
#==========================================================================
#==========================================================================
#system ("perl $path_884444_perl");

#output file 111118.txt.out 222228.txt.out
#==========================================================================
#system ("perl $path_885555_perl $formatdb_path $blastall_path $screen_blast_result_path $Reference_genome1 $Active_tes_fasta1");
system ("perl $path_884444_perl $formatdb_path $blastall_path $screen_blast_result_path $Reference_genome1 $Active_tes_fasta1 $bwa_path $add_idss1");

#output file 111118.txt.out.out.out 222228.txt.out.out.out $Active_tes_fasta1.out51.out51.out51
#==========================================================================
#system ("perl $path_886666_perl $Active_tes_fasta1");
system ("perl $path_885555_perl $Active_tes_fasta1  $add_idss1");

#output Result_forward11_22_break.txt Result_forward11_22_reference.txt
#output Result_reward11_22_break.txt  Result_reward11_22_reference.txt
#==========================================================================

system ("perl $path_886666_perl $Reference_genome1 $Active_tes_fasta1 $add_idss1");


#==========================================================================
#=head
#my $te_distribution_inreference71="$Active_tes_fasta1".".out51.out51.out51";
#system ("perl $path_887777_perl $Reference_genome1 $te_distribution_inreference71");
#=cut

system ("perl $path_887777_perl $Out_file1 $add_idss1");

# here add a blast file

#output Result_TE_insertion_position_1.txt
#==========================================================================
#system ("perl 888888_scren_TEMD-B_result.pl $Out_file1");
#**********system ("perl $path_888888_perl $Out_file1");
#**********system ("rm 111118*  222228* Result_forward11_22* Result_reward11_22*");

my $file_deletion_1=$add_idss1.".111118_id_to_privious_left.txt"; 
my $file_deletion_2=$add_idss1.".111118_left_file1.fq";           
my $file_deletion_3=$add_idss1.".111118_left_file1.fq.sam";       
my $file_deletion_4=$add_idss1.".111118_two_files.txt";           
my $file_deletion_5=$add_idss1.".222228_id_to_privious_right.txt";
my $file_deletion_6=$add_idss1.".222228_right_file2.fq";          
my $file_deletion_7=$add_idss1.".222228_right_file2.fq.sam";      
my $file_deletion_8=$add_idss1.".222228_two_files.txt";           
 my $file_deletion_9=$add_idss1.".amb";                                         
my $file_deletion_10=$add_idss1.".ann";                                           
my $file_deletion_11=$add_idss1.".bwt";                                           
my $file_deletion_12=$add_idss1.".pac";                                           
my $file_deletion_13=$add_idss1.".result1";                                       
my $file_deletion_14=$add_idss1.".result1.result1";                               
my $file_deletion_15=$add_idss1.".result1.result1.result1";                       
my $file_deletion_16=$add_idss1.".Result_forward11_22_break.txt";                 
my $file_deletion_17=$add_idss1.".Result_forward11_22_break.txt.sorted11.txt";    
my $file_deletion_18=$add_idss1.".Result_forward11_22_break.txt.sorted1.txt";     
my $file_deletion_19=$add_idss1.".Result_forward11_22_break.txt.sorted.txt";      
my $file_deletion_20=$add_idss1.".Result_forward11_22_reference.txt";             
my $file_deletion_21=$add_idss1.".Result_forward11_22_reference.txt.sorted11.txt";
my $file_deletion_22=$add_idss1.".Result_forward11_22_reference.txt.sorted1.txt"; 
my $file_deletion_23=$add_idss1.".Result_forward11_22_reference.txt.sorted.txt";  
my $file_deletion_24=$add_idss1.".Result_reward11_22_break.txt";                  
my $file_deletion_25=$add_idss1.".Result_reward11_22_break.txt.sorted11.txt";     
my $file_deletion_26=$add_idss1.".Result_reward11_22_break.txt.sorted1.txt";      
my $file_deletion_27=$add_idss1.".Result_reward11_22_break.txt.sorted.txt";       
my $file_deletion_28=$add_idss1.".Result_reward11_22_reference.txt";              
my $file_deletion_29=$add_idss1.".Result_reward11_22_reference.txt.sorted11.txt"; 
my $file_deletion_30=$add_idss1.".Result_reward11_22_reference.txt.sorted1.txt";  
my $file_deletion_31=$add_idss1.".Result_reward11_22_reference.txt.sorted.txt";   
my $file_deletion_32=$add_idss1.".Result_TE_insertion_position_1.txt";            
my $file_deletion_33=$add_idss1.".Result_TE_insertion_position_screen_result.txt";
my $file_deletion_34=$add_idss1.".Result_TE_insertion_position_screen.txt";       
my $file_deletion_35=$add_idss1.".sa";                                            
my $file_deletion_36=$add_idss1.".TEs1_temp.tem";                                
my $file_deletion_37=$add_idss1.".TEs2_temp.tem";                                 
my $file_deletion_38=$sam_out_file1;                               
my $file_deletion_39=$sam_out_file2;                                 
my $file_deletion_40=$add_idss1.".111118.txt";                               
my $file_deletion_41=$add_idss1.".222228.txt";                                 

##system ("rm $file_deletion_1 $file_deletion_2 $file_deletion_3 $file_deletion_4 $file_deletion_5 $file_deletion_6 $file_deletion_7 $file_deletion_8 $file_deletion_9 $file_deletion_10 $file_deletion_11 $file_deletion_12 $file_deletion_13 $file_deletion_14 $file_deletion_15 $file_deletion_16 $file_deletion_17 $file_deletion_18 $file_deletion_19 $file_deletion_20 $file_deletion_21 $file_deletion_22 $file_deletion_23 $file_deletion_24 $file_deletion_25 $file_deletion_26 $file_deletion_27 $file_deletion_28 $file_deletion_29 $file_deletion_30 $file_deletion_31 $file_deletion_32 $file_deletion_33 $file_deletion_34 $file_deletion_35 $file_deletion_36 $file_deletion_37 $file_deletion_38 $file_deletion_39 $file_deletion_40 $file_deletion_41");
system ("rm $file_deletion_1 $file_deletion_2 $file_deletion_3 $file_deletion_4 $file_deletion_5 $file_deletion_6 $file_deletion_7 $file_deletion_8 $file_deletion_9 $file_deletion_10 $file_deletion_11 $file_deletion_12 $file_deletion_13 $file_deletion_14 $file_deletion_15 $file_deletion_16 $file_deletion_17 $file_deletion_18 $file_deletion_19 $file_deletion_20  $file_deletion_22 $file_deletion_23 $file_deletion_24 $file_deletion_25 $file_deletion_26 $file_deletion_27 $file_deletion_28 $file_deletion_30 $file_deletion_31 $file_deletion_32 $file_deletion_33 $file_deletion_34 $file_deletion_35 $file_deletion_36 $file_deletion_37 $file_deletion_38 $file_deletion_39 $file_deletion_40 $file_deletion_41");
#system ("rm $file_deletion_1 $file_deletion_2 $file_deletion_3  $file_deletion_5 $file_deletion_6 $file_deletion_7  $file_deletion_9 $file_deletion_10 $file_deletion_11 $file_deletion_12 $file_deletion_13 $file_deletion_14 $file_deletion_15 $file_deletion_16 $file_deletion_17 $file_deletion_18 $file_deletion_19 $file_deletion_20  $file_deletion_22 $file_deletion_23 $file_deletion_24 $file_deletion_25 $file_deletion_26 $file_deletion_27 $file_deletion_28 $file_deletion_30 $file_deletion_31 $file_deletion_32 $file_deletion_33 $file_deletion_34 $file_deletion_35 $file_deletion_36 $file_deletion_37 $file_deletion_38 $file_deletion_39 $file_deletion_40 $file_deletion_41");

###########################################################################
#################################The End###################################
