####################################################################################
## PTEMD-A.pl
## The purpose of this software is to de novo scan the polymorphic transposable element (TE) using pair-end sort sequences
## Vision: 1.0.2
## Developer: Houxiang Kang
## Time: 2014-12-12
####################################################################################

use Getopt::Std;
use File::Spec;
##getopts "o:s:i:e:a:l:";
getopts "o:s:i:e:a:l:";
if ((!defined  $opt_i)|| (! defined  $opt_s) ) {
	die "************************************************************************
	Usage: PTEMD-A.pl -i ref_genome.fasta -s pair_ends.sam 
	  -h : help and usage.
	  -e : library size(default 500)
	  -a : clustered_sequences_identity% (default 95)
	  -l : minimal_sequence_length (default 100 bp)
************************************************************************\n";
}
my $Expect1 = (defined  $opt_e) ?    $opt_e : 500;
my $Length1 = (defined  $opt_l) ?    $opt_l : 100;
my $Identity1 = (defined  $opt_a) ?  $opt_a : 95;
my $Reference_genome_fasta1= "$opt_i";
my $Pair_ends_sam1="$opt_s";
#my $Out_filess_name1="$opt_o";

print "Running.....\n";

my $path_curf = File::Spec->rel2abs(__FILE__);
my ($vol_p, $dirs_p, $file_p) = File::Spec->splitpath($path_curf);

my $software_pathdir_11="$dirs_p";
my $Pindel_blat_blast_bwa_paths="$software_pathdir_11"."All_Software_paths_for_ATEMD.txt";
my $Pindel_sam2pindel_path;
my $Pindel_path;
#my $blat_path;
my $muscle_path;
my $formatdb_path;
my $blastall_path;
my $bwa_path;

print $software_pathdir_11."\n";
print $Pindel_blat_blast_bwa_paths."\n";

open (IIIN1,"$Pindel_blat_blast_bwa_paths");
while (<IIIN1>) 
{
	#print $_;
	chomp; next if ($_ eq "");
	if ($_=~/Pindel_sam2pindel\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi) {$Pindel_sam2pindel_path=$1;}
	elsif ($_=~/Pindel_x86_64\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi){$Pindel_path=$1;}
	#elsif ($_=~/Blat\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi){$blat_path=$1;}
	elsif ($_=~/Muscle\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi){$muscle_path=$1;}
	elsif ($_=~/Blast_formatdb\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi){$formatdb_path=$1;}
	elsif ($_=~/Blast_blastall\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi){$blastall_path=$1;}
	elsif ($_=~/BWA\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi){$bwa_path=$1;}
}
close IIIN1;


my $run_pindel991="$software_pathdir_11"."perl_script/"."991run_pindel.pl";
my $run_pindel992="$software_pathdir_11"."perl_script/"."992merge_all_pindel_files.pl";
#my $run_pindel993="$software_pathdir_11"."perl_script/"."993blat_matrix.pl";
my $run_pindel993="$software_pathdir_11"."perl_script/"."993muscle_matrix.pl";
my $run_pindel994="$software_pathdir_11"."perl_script/"."994cluster_sequences.pl";
##my $run_pindel995="$software_pathdir_11"."perl_script/"."995chose_sequences_from_result.pl";
my $run_pindel995="$software_pathdir_11"."perl_script/"."995chose_new_version.pl";

#=head
####################################################################################
# run the Pindel:
##system ("perl 991run_pindel.pl $Pindel_sam2pindel_path $Pindel_path $Pair_ends_sam1 $Reference_genome_fasta1 $Expect1 $software_pathdir_11");
system ("perl $run_pindel991 $Pindel_sam2pindel_path $Pindel_path $Pair_ends_sam1 $Reference_genome_fasta1 $Expect1 $software_pathdir_11");
####################################################################################
#=cut 


#my $2_file_name11;
my $file_name11_2; # isolates
if ($opt_s=~/\/*([^\/]+).sam$/) 
{
	$file_name11_2=$1;
}
my $file_name22_2="$file_name11_2"."_TEMD-A";
my $file_name33_2="$file_name11_2"."_TEMD-A1";

#=head
####################################################################################
# run the merge_all_pindel_files:
##system ("perl 992merge_all_pindel_files.pl $opt_i $file_name33_2 $file_name11_2");
system ("perl $run_pindel992 $Reference_genome_fasta1 $file_name33_2 $file_name11_2");

####################################################################################
#=cut

my $input_file3="$file_name11_2"."_all_deletion_ID.txt"; #$ARGV[0];
my $input_file3_all="$file_name11_2"."_all_deletion_ID.txt".".out"; #$ARGV[0];
my $output_file3="$input_file3"."_tmp";
my $Identity13=$Identity1; #$ARGV[1];
#=head
####################################################################################
# run the blast_matrix file:
##system ("perl 993blat_matrix.pl $input_file3  $output_file3 $Identity13 $blat_path");
##system ("perl $run_pindel993 $input_file3  $output_file3 $Identity13 $blat_path");
system ("perl $run_pindel993 $input_file3  $output_file3 $Identity13  $muscle_path");
####################################################################################
#=cut

####################################################################################
# $input_file3   fasta format sequences file
# $output_file3  clustered sequences
my $out_file4="$output_file3"."_TE_single.fasta";
my $out_file5="$output_file3"."_TE_clusters.fasta";
##system ("perl 994cluster_sequences.pl $input_file3 $output_file3 $out_file4 $out_file5");
##system ("perl $run_pindel994 $input_file3 $output_file3 $out_file4 $out_file5");
system ("perl $run_pindel994 $input_file3_all $output_file3 $out_file4 $out_file5");
####################################################################################

#my $out_file6="$output_file3"."_TE_clusters_result.fasta";
my $out_file6="$output_file3"."_TE_clusters_single.fasta";

system ("perl $run_pindel995 $muscle_path $out_file5 $out_file6");
####################################################################################
# deletions:
my $file_del_1="$input_file3";
my $file_del_2="$output_file3";
my $file_del_3="$out_file4";
my $file_del_4="$file_name22_2";
###system ("rm $file_del_1 $file_del_2 $file_del_3 $file_del_4");
system ("rm $file_del_1 $file_del_2 $file_del_3 $file_del_4  $out_file4");

####################################################################################
#####################************* THE END ************#############################



