######====================================================================
######====================================================================
####################################################################################
use Getopt::Std;
use File::Spec;
#getopts "o:s:i:e:a:l:";
getopts "r:";
if ((!defined  $opt_r) ) {
	die "************************************************************************
	Usage:PreTEMD-B.pl -r reference_genome.fasta 
************************************************************************\n";
}
my $Reference_genome1 = $opt_r;


my $path_curf = File::Spec->rel2abs(__FILE__);
my ($vol_p, $dirs_p, $file_p) = File::Spec->splitpath($path_curf);

my $software_pathdir_11="$dirs_p";
my $Pindel_blat_blast_bwa_paths="$software_pathdir_11"."All_Software_paths_for_ATEMD.txt";
my $Pindel_sam2pindel_path;
my $Pindel_path;
my $blat_path;
my $formatdb_path;
my $blastall_path;
my $bwa_path;

print $software_pathdir_11."\n";
print $Pindel_blat_blast_bwa_paths."\n";

open (IIIN1,"$Pindel_blat_blast_bwa_paths");
while (<IIIN1>) 
{
	#print $_;
	chomp; next if ($_ eq "");
	if ($_=~/Pindel_sam2pindel\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi) {$Pindel_sam2pindel_path=$1;}
	elsif ($_=~/Pindel_x86_64\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi){$Pindel_path=$1;}
	elsif ($_=~/Blat\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi){$blat_path=$1;}
	elsif ($_=~/Blast_formatdb\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi){$formatdb_path=$1;}
	elsif ($_=~/Blast_blastall\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi){$blastall_path=$1;}
	elsif ($_=~/BWA\s*\=\s*\"*\s*([^\"]+)\s*\"*/gi){$bwa_path=$1;}
}
close IIIN1;
system ("$bwa_path index $Reference_genome1");

#########==== the end =====##########

