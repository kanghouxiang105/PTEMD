use strict;
system ("mkdir seq_alignment_engine");
system ("pwd > The_original_path.txt");
open (IN1,"The_original_path.txt");
my $original_path1;
while (<IN1>) { chomp; if ($_=~/([^\s]+)/) {$original_path1=$1;}}
print $original_path1."\n";
my $path1="./alignment_softwares";
#=====================================================================
#=====================================================================
# 1INSTALL pindel
system ("tar -xf  $path1/pindel.tar");
system ("g++ $path1/SAM_2_PINDEL_cin_2010Dec2.cpp -o sam2pindel");
system ("cp ./pindel_x86_64 ./seq_alignment_engine");
system ("cp ./sam2pindel ./seq_alignment_engine");
system ("rm  ./pindel_mac ./pindel_x86_64 ./sam2pindel");
#=====================================================================
#=====================================================================
# Install blat
=HEAD
system ("unzip $path1/blatSuite.34.zip");
system ("cp ./blat ./seq_alignment_engine");
system ("cp ./faToNib ./seq_alignment_engine");
system ("cp ./faToTwoBit ./seq_alignment_engine");
system ("cp ./gfClient ./seq_alignment_engine");
system ("cp ./gfServer ./seq_alignment_engine");
system ("cp ./nibFrag ./seq_alignment_engine");
system ("cp ./pslPretty ./seq_alignment_engine");
system ("cp ./pslReps ./seq_alignment_engine");
system ("cp ./pslSort ./seq_alignment_engine");
system ("cp ./twoBitInfo ./seq_alignment_engine");
system ("cp ./twoBitToFa ./seq_alignment_engine");
system ("cp ./webBlat ./seq_alignment_engine");
system ("cp ./version.doc ./seq_alignment_engine");
system ("cp ./11.ooc ./seq_alignment_engine");
system ("rm ./blat ./faToNib ./faToTwoBit ./gfClient ./gfServer ./nibFrag ./pslPretty");
system ("rm  ./pslReps ./pslSort ./twoBitInfo ./twoBitToFa ./webBlat ./version.doc ./11.ooc ");
=cut
#=====================================================================
#=====================================================================
# 2 Install muscle
system ("tar zxvf  $path1/muscle3.8.31_i86linux64.tar.gz");
#=====================================================================
#=====================================================================
# 3 Install blast
system ("tar zxvf $path1/blast-2.2.26-x64-linux.tar.gz");
# blastall and formatdb in 
#=====================================================================
#=====================================================================
# 4 Install bwa
system ("tar jxvf  $path1/bwa-0.7.10.tar.bz2");
#system ("cd $path1/bwa-0.7.10");
chdir ("./bwa-0.7.10");
system ("make");
chdir ("../");
#=====================================================================
#=====================================================================
open (OUT1,">All_Software_paths_for_ATEMD.txt");
print OUT1 "#PTEMD requires four other programs: 1: Pindel; 2: BWA 3: Blast; 4 Blat\n";
print OUT1 "#The four program will be automatically installed After run the install file: INSTALL.pl\n";
print OUT1 "#Following is the path for the four softwares\n";
print OUT1 "#Please check the paths if the PTEMD program can't run normally\n";
print OUT1 "#If have problems, You can follow the README file to install the four programs one by one and add the correct paths to following\n";
print OUT1 "##############################################################\n\n";
print OUT1 "#1:  Pindel(A program which is able to scanning variations including long size deletions)\n";
print OUT1 "Pindel_sam2pindel=\"$original_path1/seq_alignment_engine/sam2pindel\"\n";
print OUT1 "Pindel_x86_64=\"$original_path1/seq_alignment_engine/pindel_x86_64\"\n\n";
print OUT1 "#2:  BWA (A program which is able to quickly align the high-though sort reads to the reference genome)\n";
print OUT1 "BWA=\"$original_path1/bwa-0.7.10/bwa\"\n\n";
print OUT1 "#3:  Blast (A sequences alignment engine)\n";
print OUT1 "Blast_formatdb=\"$original_path1/blast-2.2.26/bin/formatdb\"\n";
print OUT1 "Blast_blastall=\"$original_path1/blast-2.2.26/bin/blastall\"\n\n";
#print OUT1 "#4:  Blat (A sequences alignment engine)\n";
#print OUT1 "Blat=\"$original_path1/seq_alignment_engine/blat\"\n\n";
print OUT1 "#4:  Muscle (A sequences alignment engine)\n";
print OUT1 "Muscle=\"$original_path1/muscle3.8.31_i86linux64\"\n\n";
close OUT1;
system ("chmod 777 PTEMD-A.pl");
system ("chmod 777 PTEMD-B.pl");




